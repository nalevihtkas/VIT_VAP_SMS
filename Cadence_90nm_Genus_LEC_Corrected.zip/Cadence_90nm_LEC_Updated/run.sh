#!/usr/bin/env bash
# ------------------------------------------------------------------
# Optional one-shot runner.  Usage:
#   ./run.sh synth   -> Genus: golden + faulty netlists
#   ./run.sh lib     -> Conformal: .lib -> .v cell library
#   ./run.sh pass    -> LEC PASS case
#   ./run.sh fail    -> LEC FAIL case
#   ./run.sh all     -> everything above, then a short summary
#   ./run.sh clean   -> delete generated files
# Paths are NOT set here - edit them inside the .tcl / .do scripts.
# ------------------------------------------------------------------
set -uo pipefail
cd "$(dirname "$0")"
mkdir -p logs synthesis/reports synthesis/outputs

LEC_CMD="lec -XL -nogui -color -64 -dofile"

summary () {
  for c in pass fail; do
    f=logs/lec_$c.log
    echo "------ LEC ${c^^} case ($f) ------"
    if [ -f "$f" ]; then
      grep -E -i "^ *(Equivalent|Non-equivalent|Aborted|Not-compared)[[:space:]]" "$f" | tail -4 \
        || echo "  (no compare summary found - open $f)"
    else
      echo "  log not found"
    fi
  done
}

case "${1:-all}" in
  synth) (cd synthesis && genus -files synthesis.tcl        -log ../logs/genus_pass  \
                       && genus -files synthesis_faulty.tcl -log ../logs/genus_fail) ;;
  lib)   (cd LEC && $LEC_CMD lib_convert.do) ;;
  pass)  (cd LEC && $LEC_CMD lec_pass.do) ;;
  fail)  (cd LEC && $LEC_CMD lec_fail.do) ;;
  all)   "$0" synth || { echo "Genus failed - see logs/"; exit 1; }
         "$0" lib   || { echo "lib conversion failed - see logs/lib_convert.log"; exit 1; }
         "$0" pass
         "$0" fail
         summary ;;
  summary) summary ;;
  clean) rm -rf synthesis/outputs/* synthesis/reports/* logs/* LIB/slow.v \
                synthesis/genus.* synthesis/fv LEC/*.log* LEC/*.rpt ;;
  *) echo "Usage: ./run.sh {synth|lib|pass|fail|all|summary|clean}"; exit 2 ;;
esac
