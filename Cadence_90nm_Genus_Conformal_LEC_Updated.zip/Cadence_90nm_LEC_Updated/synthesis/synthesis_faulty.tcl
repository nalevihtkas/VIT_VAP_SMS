# Synthesize intentionally faulty RTL with the same 90nm library.
set_db init_lib_search_path ../LIB/
set_db init_hdl_search_path ../RTL/
read_libs slow_vdd1v0_basicCells.lib
read_hdl design_faulty.v
elaborate design
check_design -unresolved
read_sdc ../Constraints/constraints_top.sdc
set_db syn_generic_effort medium
set_db syn_map_effort medium
set_db syn_opt_effort medium
syn_generic
syn_map
syn_opt
report_timing > reports/report_timing_faulty.rpt
report_area > reports/report_area_faulty.rpt
write_hdl > outputs/design_netlist_faulty.v
