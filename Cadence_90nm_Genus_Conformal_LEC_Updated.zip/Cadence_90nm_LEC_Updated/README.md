# Cadence Genus + Conformal LEC, 90nm

This package uses the command syntax and relative paths requested. It runs two separate Genus synthesis jobs (correct and intentionally faulty RTL), converts the 90nm Liberty file to a Verilog library for Conformal, then checks both mapped netlists against the original RTL.

## Before running
1. Copy your licensed **90nm** Liberty file to `LIB/slow_vdd1v0_basicCells.lib` (or change that name in both synthesis Tcl files and the conversion DO file).
2. Ensure `genus` and `lec` are in PATH and licensed.
3. On Linux, run `chmod +x run.sh` and `./run.sh all` from the package root.

## Individual commands
- `./run.sh synth` : synthesize correct and faulty RTL separately.
- `./run.sh lib` : convert Liberty into `LIB/slow_vdd1v0_basicCells.v`.
- `./run.sh pass` : RTL vs correct mapped netlist (expected equivalent).
- `./run.sh fail` : RTL vs faulty mapped netlist (expected non-equivalent).

## Manual commands
From `synthesis/`: `genus -files synthesis.tcl`, then `genus -files synthesis_faulty.tcl`.
From `LEC/`: `lec -nogui -dofile lib_convert.do`, then `lec -nogui -dofile lec_pass.do`, then `lec -nogui -dofile lec_fail.do`.

## Notes
- The supplied library name is a placeholder, **not** a bundled 90nm library. You must provide a real Liberty file and its cells must support the RTL mapping.
- FAIL is caused by a deliberately incorrect RTL version that is *also synthesized*, not by manually editing unpredictable mapped-cell names.
- LEC command availability/report syntax can vary by Cadence release. Review actual tool logs, unresolved modules, compare-point status and reports; shell exit code alone is not proof of equivalence.
- This package has not been executed against licensed Cadence tools in this environment.
