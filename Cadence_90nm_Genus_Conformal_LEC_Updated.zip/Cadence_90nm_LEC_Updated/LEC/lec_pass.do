set log file lec_pass.log -replace
read library ../LIB/slow_vdd1v0_basicCells.v -verilog -both
read design ../RTL/design.v -verilog -golden
read design ../synthesis/outputs/design_netlist.v -verilog -revised
set root module design -golden
set root module design -revised
set system mode lec
add compared point -all
compare
report verification -verbose > lec_pass_report.rpt
