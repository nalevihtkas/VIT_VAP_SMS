set log file lib_convert.log -replace
read library ../LIB/slow_vdd1v0_basicCells.lib -liberty
write library ../LIB/slow_vdd1v0_basicCells.v -verilog -replace
