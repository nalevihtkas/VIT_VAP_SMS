#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
case "${1:-all}" in
 synth) (cd synthesis && genus -files synthesis.tcl -log genus.log && genus -files synthesis_faulty.tcl -log genus_faulty.log) ;;
 lib) (cd LEC && lec -nogui -dofile lib_convert.do) ;;
 pass) (cd LEC && lec -nogui -dofile lec_pass.do) ;;
 fail) (cd LEC && lec -nogui -dofile lec_fail.do) ;;
 all) "$0" synth; "$0" lib; "$0" pass; "$0" fail ;;
 *) echo 'Usage: ./run.sh {synth|lib|pass|fail|all}'; exit 2 ;;
esac
