module design(input clk,input rst_n,input sel,input [7:0] a,b,c,output reg [8:0] y);
wire [8:0] add_result={1'b0,a}+{1'b0,b};
wire [8:0] sub_result={1'b0,a}-{1'b0,b};
wire [8:0] next_y=sel ? (add_result ^ {1'b0,c}) : (sub_result+{1'b0,c});
always @(posedge clk or negedge rst_n) if(!rst_n) y<=9'b0; else y<=next_y;
endmodule
