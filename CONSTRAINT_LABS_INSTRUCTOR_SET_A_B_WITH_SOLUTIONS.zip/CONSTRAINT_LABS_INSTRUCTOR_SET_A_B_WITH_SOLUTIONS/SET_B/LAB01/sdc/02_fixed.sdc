create_clock -name CLK -period 5.0 [get_ports clk]
# Sign-off spec: setup uncertainty 0.30 ns, hold uncertainty 0.05 ns
set_clock_uncertainty -setup 0.3 [get_clocks CLK]
set_clock_uncertainty -hold 0.05 [get_clocks CLK]
