create_clock -name CLKA -period 4 [get_ports clka]
create_clock -name CLKB -period 3 [get_ports clkb]
# CLKA and CLKB come from independent oscillators; the crossing uses a 2-flop synchronizer
set_clock_groups -asynchronous -group [get_clocks CLKA] -group [get_clocks CLKB]
