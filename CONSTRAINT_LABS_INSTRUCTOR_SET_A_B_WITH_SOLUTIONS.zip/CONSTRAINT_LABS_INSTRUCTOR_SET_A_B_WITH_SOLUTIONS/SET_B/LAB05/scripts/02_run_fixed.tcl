# CONSTRAINT_LAB 05 SET B - FIXED constraints
# Run from this lab folder:  tempus -files scripts/02_run_fixed.tcl
read_lib lib/teaching_sta.lib
read_verilog netlist/design.v
set_top_module cons_lab05
read_sdc sdc/02_fixed.sdc
report_timing -late  -path_type full_clock -from [get_pins U_TX/CLK] -to [get_pins U_SYNC1/D]
report_timing -early -path_type full_clock -from [get_pins U_TX/CLK] -to [get_pins U_SYNC1/D]
report_timing -late  -path_type full_clock -from [get_pins U_SYNC1/CLK] -to [get_pins U_SYNC2/D]
report_timing -early -path_type full_clock -from [get_pins U_SYNC1/CLK] -to [get_pins U_SYNC2/D]
exit
