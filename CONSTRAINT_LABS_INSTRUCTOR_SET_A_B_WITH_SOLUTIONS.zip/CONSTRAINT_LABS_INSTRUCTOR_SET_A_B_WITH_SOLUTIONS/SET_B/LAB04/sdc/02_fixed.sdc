# Spec: 100 MHz clock with 50 % duty cycle
create_clock -name CLK -period 10 -waveform {0 5} [get_ports clk]
