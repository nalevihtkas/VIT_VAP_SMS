# CONSTRAINT_LAB 03 SET B - GIVEN constraints
# Run from this lab folder:  tempus -files scripts/01_run_given.tcl
read_lib lib/teaching_sta.lib
read_verilog netlist/design.v
set_top_module cons_lab03
read_sdc sdc/01_given.sdc
report_timing -late  -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D]
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D]
exit
