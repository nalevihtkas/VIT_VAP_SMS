create_clock -name CLK -period 2.5 [get_ports clk]
# Result is sampled every 3rd cycle: 3-cycle setup, 2-cycle hold
set_multicycle_path 3 -setup -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D]
set_multicycle_path 2 -hold  -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D]
