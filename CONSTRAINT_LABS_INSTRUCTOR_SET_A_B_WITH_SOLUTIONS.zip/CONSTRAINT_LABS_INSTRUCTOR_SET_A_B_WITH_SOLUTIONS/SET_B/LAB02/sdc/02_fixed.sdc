create_clock -name CLK -period 3.6 [get_ports clk]
# Post-CTS: use the real clock-network delays
set_propagated_clock [all_clocks]
