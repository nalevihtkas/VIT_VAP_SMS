#!/bin/bash
set -e
cd "$(dirname "$0")"
mkdir -p reports
tempus -files scripts/01_run_given.tcl | tee reports/01_given.log
tempus -files scripts/02_run_fixed.tcl | tee reports/02_fixed.log
