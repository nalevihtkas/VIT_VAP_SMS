# CONSTRAINT_LAB 04 SET A - FIXED constraints
# Run from this lab folder:  tempus -files scripts/02_run_fixed.tcl
read_lib lib/teaching_sta.lib
read_verilog netlist/design.v
set_top_module cons_lab04
read_sdc sdc/02_fixed.sdc
report_timing -late  -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D]
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D]
exit
