# Spec: 8 ns clock, high for 2.5 ns (31.25 % duty cycle)
create_clock -name CLK -period 8.0 -waveform {0 2.5} [get_ports clk]
