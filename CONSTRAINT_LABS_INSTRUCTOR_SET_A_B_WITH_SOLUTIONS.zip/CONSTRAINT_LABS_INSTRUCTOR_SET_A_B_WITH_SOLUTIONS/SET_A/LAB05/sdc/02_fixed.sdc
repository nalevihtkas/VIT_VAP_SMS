create_clock -name CLK -period 5.0 [get_ports clk]
# U_CFG_L is static configuration: written only while the block is idle
set_false_path -from [get_pins U_CFG_L/CLK] -to [get_pins U_CFG_C/D]
