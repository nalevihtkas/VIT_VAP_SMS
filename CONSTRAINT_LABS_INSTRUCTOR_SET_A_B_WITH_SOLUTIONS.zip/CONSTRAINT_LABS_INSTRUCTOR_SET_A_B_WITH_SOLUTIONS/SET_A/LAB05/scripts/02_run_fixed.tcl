# CONSTRAINT_LAB 05 SET A - FIXED constraints
# Run from this lab folder:  tempus -files scripts/02_run_fixed.tcl
read_lib lib/teaching_sta.lib
read_verilog netlist/design.v
set_top_module cons_lab05
read_sdc sdc/02_fixed.sdc
report_timing -late  -path_type full_clock -from [get_pins U_DATA_L/CLK] -to [get_pins U_DATA_C/D]
report_timing -early -path_type full_clock -from [get_pins U_DATA_L/CLK] -to [get_pins U_DATA_C/D]
report_timing -late  -path_type full_clock -from [get_pins U_CFG_L/CLK]  -to [get_pins U_CFG_C/D]
report_timing -late  -path_type full_clock -max_paths 5
exit
