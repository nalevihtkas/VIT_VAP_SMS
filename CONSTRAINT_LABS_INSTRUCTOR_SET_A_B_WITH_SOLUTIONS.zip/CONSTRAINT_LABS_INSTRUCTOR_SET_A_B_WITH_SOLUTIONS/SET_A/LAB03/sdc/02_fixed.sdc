create_clock -name CLK -period 3.0 [get_ports clk]
# U_CAPTURE is enabled every 2nd cycle: 2-cycle setup, hold back to the launch edge
set_multicycle_path 2 -setup -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D]
set_multicycle_path 1 -hold  -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D]
