create_clock -name CLK -period 4.2 [get_ports clk]
# Clock tree is built (post-CTS netlist): use real clock-network delays
set_propagated_clock [all_clocks]
