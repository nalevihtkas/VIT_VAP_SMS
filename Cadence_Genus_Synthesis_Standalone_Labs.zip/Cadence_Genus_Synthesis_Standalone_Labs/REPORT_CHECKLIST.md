# Report Checklist

For every before/after experiment record:

| Metric | Before | After | Interpretation |
|---|---:|---:|---|
| Cell area | | | |
| Gate/cell count | | | |
| Critical delay / timing | | | |
| WNS/TNS (sequential labs) | | | |
| Power (illustrative teaching library) | | | |
| Structural change in mapped netlist | | | |

For datapath labs also record latency and throughput implications.
