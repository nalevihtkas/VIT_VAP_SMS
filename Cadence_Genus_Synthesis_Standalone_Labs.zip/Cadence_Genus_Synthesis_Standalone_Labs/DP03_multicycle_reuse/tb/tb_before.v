`timescale 1ns/1ps
module tb_top;
reg clk=0,rst_n=0,start=0; reg [7:0] a=3,b=4,c=5,d=6; wire [16:0] y; wire done;
before_top dut(.clk(clk),.rst_n(rst_n),.start(start),.a(a),.b(b),.c(c),.d(d),.y(y),.done(done));
always #5 clk=~clk;
initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top); #12 rst_n=1; #8 start=1; #10 start=0; #80 $finish; end
endmodule
