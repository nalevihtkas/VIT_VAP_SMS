module before_top(input wire clk,rst_n,start,input wire [7:0] a,b,c,d,
output reg [16:0] y, output reg done);
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) begin y<=0; done<=0; end
 else begin done<=start; if(start) y<=(a*b)+(c*d); end
end
endmodule
