module after_top(input wire clk,rst_n,start,input wire [7:0] a,b,c,d,
output reg [16:0] y, output reg done);
localparam IDLE=2'd0,M1=2'd1,M2=2'd2,FIN=2'd3;
reg [1:0] state;
reg [15:0] p1,p2;
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) begin state<=IDLE;p1<=0;p2<=0;y<=0;done<=0; end
 else begin
  done<=1'b0;
  case(state)
   IDLE: if(start) state<=M1;
   M1: begin p1<=a*b; state<=M2; end
   M2: begin p2<=c*d; state<=FIN; end
   FIN: begin y<={1'b0,p1}+{1'b0,p2}; done<=1'b1; state<=IDLE; end
   default: state<=IDLE;
  endcase
 end
end
endmodule
