source ../common/scripts/common_setup.tcl
set TOP before_top
read_hdl "$LAB_DIR/rtl/before.v"
elaborate $TOP
check_design -unresolved
read_sdc "$LAB_DIR/sdc/before.sdc"

# IMPORTANT: exact retiming controls are Genus-release dependent.
# Run the next command interactively first:
help *retime*

# The attached notes give this only as a representative example:
# set_db design:$TOP .retime true

# After identifying the supported attribute in your release, enable it here.
syn_generic
syn_map
syn_opt
basic_reports retimed
