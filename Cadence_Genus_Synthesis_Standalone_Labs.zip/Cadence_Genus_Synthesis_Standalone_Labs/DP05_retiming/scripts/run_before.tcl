source ../common/scripts/common_setup.tcl
set TOP before_top
read_hdl "$LAB_DIR/rtl/before.v"
elaborate $TOP
check_design -unresolved
read_sdc "$LAB_DIR/sdc/before.sdc"
# Retiming is release-dependent.
# Inspect supported controls before enabling:
help *retime*
# Representative concept from the notes:
# set_db design:$TOP .retime true

syn_generic
syn_map
syn_opt
basic_reports before
