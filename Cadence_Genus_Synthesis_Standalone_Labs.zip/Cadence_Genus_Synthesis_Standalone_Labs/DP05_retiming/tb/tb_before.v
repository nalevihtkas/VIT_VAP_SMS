`timescale 1ns/1ps
module tb_top;
reg clk=0,rst_n=0; reg [7:0] a=1,b=2,c=3,d=4; wire [9:0] y10; wire [16:0] y17;
wire [9:0] y;
before_top dut(.clk(clk),.rst_n(rst_n),.a(a),.b(b),.c(c),.d(d),.y(y));
always #2 clk=~clk;
initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top); #4.8 rst_n=1; repeat(20) begin #4; a=a+1;b=b+3;c=c+2; d=d+1; end $finish; end
endmodule
