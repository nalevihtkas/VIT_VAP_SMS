module before_top(input wire clk,rst_n,input wire [7:0] a,b,c,d,output reg [9:0] y);
reg [8:0] s1;
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) begin s1<=9'd0;y<=10'd0; end
 else begin
  s1<={1'b0,a}+{1'b0,b};
  y<={1'b0,s1}+c+d;
 end
end
endmodule
