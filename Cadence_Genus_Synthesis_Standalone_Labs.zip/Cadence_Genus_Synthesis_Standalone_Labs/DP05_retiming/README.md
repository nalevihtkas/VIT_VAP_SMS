# DP05_retiming — Retiming

**Category:** Datapath

## Objective
Demonstrate the synthesis behavior corresponding to **Retiming** from the attached RTL synthesis notes.

## Files
- `rtl/before.v` — baseline or unoptimized formulation.

- `sdc/` — constraints.
- `scripts/run_before.tcl` — baseline Genus run.

- `reports/` — generated area/gates/timing/power/QoR reports.
- `netlist/` — generated mapped netlists.

## Run
```bash
cd DP05_retiming
./run_lab.sh
```

## Compare
Check `reports/*_area.rpt`, `*_gates.rpt`, `*_timing.rpt`, and the mapped Verilog in `netlist/`.

## Expected teaching observation
This lab is intentionally a single RTL candidate plus a Tcl retiming template because the source notes state that retiming is normally a synthesis transformation, not a separate manually rewritten RTL. Enable the exact retiming attribute supported by your installed release.

## Important
The supplied `common/lib/teaching.lib` is a synthetic classroom library, not a foundry PDK. It is intended to make synthesis structure and qualitative PPA trends observable. Do not use its absolute PPA values for publication or silicon signoff.
