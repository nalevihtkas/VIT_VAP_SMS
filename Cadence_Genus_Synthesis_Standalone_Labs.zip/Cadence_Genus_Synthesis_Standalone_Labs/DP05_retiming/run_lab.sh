#!/bin/sh
set -e
genus -f scripts/run_before.tcl
echo "Retiming: see scripts/run_retiming_TEMPLATE.tcl and README.md"
