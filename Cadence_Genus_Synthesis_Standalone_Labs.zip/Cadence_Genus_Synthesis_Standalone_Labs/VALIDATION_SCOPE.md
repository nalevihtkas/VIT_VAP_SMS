# Validation Scope

The package is statically cross-checked for file presence and module/Tcl consistency.

Run:
```bash
python3 common/check_package.py
```

The supplied Liberty file is synthetic. Cadence Genus itself is not installed in the artifact-generation environment, so actual Genus execution could not be performed here.

Release-dependent items:
- `ungroup` syntax may vary.
- library `dont_use` database syntax may vary.
- buffer insertion details depend on DRC constraints/library.
- retiming controls are explicitly release-dependent in the source notes.

Therefore the package avoids claiming signoff or real-PDK behavior.
