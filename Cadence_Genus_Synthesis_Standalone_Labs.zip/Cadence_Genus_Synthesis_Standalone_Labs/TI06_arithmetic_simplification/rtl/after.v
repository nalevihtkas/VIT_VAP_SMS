module after_top(input wire [7:0] a, output wire [10:0] y);
assign y = {a,3'b000};
endmodule
