module before_top(input wire [7:0] a, output wire [10:0] y);
assign y = a * 8;
endmodule
