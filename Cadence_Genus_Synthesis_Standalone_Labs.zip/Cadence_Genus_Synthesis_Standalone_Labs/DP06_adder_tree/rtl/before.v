module before_top(input wire [7:0] a,b,c,d,output wire [9:0] y);
wire [8:0] s1={1'b0,a}+{1'b0,b};
wire [9:0] s2={1'b0,s1}+c;
assign y=s2+d;
endmodule
