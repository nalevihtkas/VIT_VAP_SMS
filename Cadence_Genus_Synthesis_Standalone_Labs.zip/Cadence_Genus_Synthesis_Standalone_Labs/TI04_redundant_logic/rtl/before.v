module before_top(input wire a,b, output wire y);
wire n1,n2;
assign n1 = a & b;
assign n2 = a & b;
assign y = n1 | n2;
endmodule
