module after_top(input wire [7:0] a, output wire y);
assign y = ~|a;
endmodule
