module before_top(input wire [7:0] a, output wire y);
assign y = (a == 8'd0);
endmodule
