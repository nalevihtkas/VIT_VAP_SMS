# TI08_compare_zero — Comparator-to-Zero Simplification

**Category:** Technology-Independent

## Objective
Demonstrate the synthesis behavior corresponding to **Comparator-to-Zero Simplification** from the attached RTL synthesis notes.

## Files
- `rtl/before.v` — baseline or unoptimized formulation.
- `rtl/after.v` — explicit optimized formulation.

- `sdc/` — constraints.
- `scripts/run_before.tcl` — baseline Genus run.
- `scripts/run_after.tcl` — optimized Genus run.

- `reports/` — generated area/gates/timing/power/QoR reports.
- `netlist/` — generated mapped netlists.

## Run
```bash
cd TI08_compare_zero
./run_lab.sh
```

## Compare
Check `reports/*_area.rpt`, `*_gates.rpt`, `*_timing.rpt`, and the mapped Verilog in `netlist/`.

## Expected teaching observation
Compare the structural and PPA consequences of the before and after formulations.

## Important
The supplied `common/lib/teaching.lib` is a synthetic classroom library, not a foundry PDK. It is intended to make synthesis structure and qualitative PPA trends observable. Do not use its absolute PPA values for publication or silicon signoff.
