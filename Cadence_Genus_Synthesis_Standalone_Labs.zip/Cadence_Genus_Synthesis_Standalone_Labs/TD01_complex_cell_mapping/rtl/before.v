module before_top(input wire a,b,c,d, output wire y_n);
wire p = a & b;
wire q = c & d;
assign y_n = ~(p | q);
endmodule
