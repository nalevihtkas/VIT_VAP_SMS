module after_top(input wire a,b,c,d, output wire y_n);
assign y_n = ~((a & b) | (c & d));
endmodule
