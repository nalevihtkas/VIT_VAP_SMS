module before_top(input wire a,b, output wire y);
wire na=~a, nb=~b;
wire t1=a&nb, t2=na&b;
assign y=t1|t2;
endmodule
