module before_top(input wire a,b, output wire y);
wire enable = 1'b1;
assign y = enable ? (a & b) : 1'b0;
endmodule
