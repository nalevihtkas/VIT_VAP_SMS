module after_top(input wire clk,rst_n,input wire [7:0] a,b,c,output reg [16:0] y);
reg [15:0] product;
reg [7:0] c_dly;
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) begin product<=16'd0;c_dly<=8'd0;y<=17'd0; end
 else begin
  product<=a*b;
  c_dly<=c;
  y<={1'b0,product}+{9'd0,c_dly};
 end
end
endmodule
