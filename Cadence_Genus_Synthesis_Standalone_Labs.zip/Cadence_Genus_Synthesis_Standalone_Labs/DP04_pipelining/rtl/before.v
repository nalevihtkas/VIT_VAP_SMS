module before_top(input wire clk,rst_n,input wire [7:0] a,b,c,output reg [16:0] y);
always @(posedge clk or negedge rst_n) begin
 if(!rst_n) y<=17'd0;
 else y<=(a*b)+c;
end
endmodule
