module after_top(input wire [7:0] a,b,c,d, output wire [9:0] y1,y2);
wire [8:0] common_sum;
assign common_sum = {1'b0,a}+{1'b0,b};
assign y1 = {1'b0,common_sum}+c;
assign y2 = {1'b0,common_sum}+d;
endmodule
