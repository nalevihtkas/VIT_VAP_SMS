module before_top(input wire [7:0] a,b,c,d, output wire [9:0] y1,y2);
wire [8:0] s1 = {1'b0,a}+{1'b0,b};
wire [8:0] s2 = {1'b0,a}+{1'b0,b};
assign y1 = {1'b0,s1}+c;
assign y2 = {1'b0,s2}+d;
endmodule
