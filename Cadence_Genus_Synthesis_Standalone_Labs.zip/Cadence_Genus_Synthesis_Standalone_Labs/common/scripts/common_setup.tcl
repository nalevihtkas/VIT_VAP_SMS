# Common Cadence Genus setup for all teaching labs.
# Run Genus from the individual LAB folder.
set LAB_DIR [pwd]
set ROOT_DIR [file normalize "$LAB_DIR/.."]
set COMMON "$ROOT_DIR/common"
set REPORT_DIR "$LAB_DIR/reports"
set NETLIST_DIR "$LAB_DIR/netlist"
file mkdir $REPORT_DIR
file mkdir $NETLIST_DIR

set_db init_hdl_search_path "$LAB_DIR/rtl"
set_db init_lib_search_path "$COMMON/lib"
read_libs "$COMMON/lib/teaching.lib"

proc basic_reports {tag} {
  global REPORT_DIR NETLIST_DIR
  report area   > "$REPORT_DIR/${tag}_area.rpt"
  report gates  > "$REPORT_DIR/${tag}_gates.rpt"
  catch {report timing > "$REPORT_DIR/${tag}_timing.rpt"}
  catch {report power  > "$REPORT_DIR/${tag}_power.rpt"}
  catch {report qor    > "$REPORT_DIR/${tag}_qor.rpt"}
  write_hdl > "$NETLIST_DIR/${tag}_mapped.v"
}
