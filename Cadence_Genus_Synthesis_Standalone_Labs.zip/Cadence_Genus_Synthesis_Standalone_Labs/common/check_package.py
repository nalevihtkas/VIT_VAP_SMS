from pathlib import Path
import re, sys
root = Path(__file__).resolve().parents[1]
errors=[]
labs=[p for p in root.iterdir() if p.is_dir() and p.name not in ("common",) and (p/"scripts").exists()]
if not (root/"common/lib/teaching.lib").exists():
    errors.append("Missing teaching.lib")
for lab in labs:
    for req in ["rtl/before.v","sdc/before.sdc","scripts/run_before.tcl","run_lab.sh","README.md"]:
        if not (lab/req).exists(): errors.append(f"{lab.name}: missing {req}")
    txt=(lab/"scripts/run_before.tcl").read_text()
    m=re.search(r"set TOP\s+(\w+)",txt)
    if m:
        top=m.group(1)
        rtl=(lab/"rtl/before.v").read_text()
        if not re.search(r"\bmodule\s+"+re.escape(top)+r"\b",rtl):
            errors.append(f"{lab.name}: TOP {top} not found in before.v")
    if (lab/"rtl/after.v").exists():
        for req in ["sdc/after.sdc","scripts/run_after.tcl"]:
            if not (lab/req).exists(): errors.append(f"{lab.name}: missing {req}")
        txt=(lab/"scripts/run_after.tcl").read_text()
        m=re.search(r"set TOP\s+(\w+)",txt)
        if m:
            top=m.group(1); rtl=(lab/"rtl/after.v").read_text()
            if not re.search(r"\bmodule\s+"+re.escape(top)+r"\b",rtl):
                errors.append(f"{lab.name}: TOP {top} not found in after.v")
print(f"Labs checked: {len(labs)}")
if errors:
    print("STATIC CHECK: FAIL")
    for e in errors: print(" -",e)
    sys.exit(1)
print("STATIC CHECK: PASS")
