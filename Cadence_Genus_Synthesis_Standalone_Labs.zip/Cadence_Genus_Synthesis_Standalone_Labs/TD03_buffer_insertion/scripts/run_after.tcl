source ../common/scripts/common_setup.tcl
set TOP after_top
read_hdl "$LAB_DIR/rtl/after.v"
elaborate $TOP
check_design -unresolved
read_sdc "$LAB_DIR/sdc/after.sdc"
catch {set_max_fanout 8 [current_design]}
catch {set_max_transition 0.10 [current_design]}
catch {set_max_capacitance 0.10 [current_design]}
syn_generic
syn_map
syn_opt
basic_reports after
