module before_top(input wire a,b, output wire [31:0] y);
wire common = a & b;
assign y = {32{common}};
endmodule
