module before_top(input wire a,b,c,d, output wire y);
wire n1,n2;
assign n1=a&b;
assign n2=n1&c;
assign y=n2&d;
endmodule
