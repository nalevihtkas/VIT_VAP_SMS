module after_top(input wire a,b,c,d, output wire y);
wire n1,n2;
assign n1=a&b;
assign n2=c&d;
assign y=n1&n2;
endmodule
