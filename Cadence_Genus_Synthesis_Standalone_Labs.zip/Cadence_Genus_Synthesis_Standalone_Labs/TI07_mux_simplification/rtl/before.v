module before_top(input wire a, input wire sel, output wire y);
assign y = sel ? a : a;
endmodule
