module after_top(input wire a, input wire sel, output wire y);
assign y = a;
endmodule
