module before_top(input wire a,b, output wire y);
wire t1,t2;
assign t1 = a & b;
assign t2 = a & ~b;
assign y = t1 | t2;
endmodule
