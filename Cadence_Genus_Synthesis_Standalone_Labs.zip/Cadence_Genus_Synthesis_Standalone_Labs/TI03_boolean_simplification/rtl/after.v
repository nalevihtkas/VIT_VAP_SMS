module after_top(input wire a,b, output wire y);
assign y = a;
endmodule
