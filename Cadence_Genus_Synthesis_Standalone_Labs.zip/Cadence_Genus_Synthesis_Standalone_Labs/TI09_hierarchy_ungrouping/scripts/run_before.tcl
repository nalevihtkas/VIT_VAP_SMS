source ../common/scripts/common_setup.tcl
set TOP before_top
read_hdl "$LAB_DIR/rtl/before.v"
elaborate $TOP
check_design -unresolved
read_sdc "$LAB_DIR/sdc/before.sdc"
catch {ungroup -all -flatten}
syn_generic
syn_map
syn_opt
basic_reports before
