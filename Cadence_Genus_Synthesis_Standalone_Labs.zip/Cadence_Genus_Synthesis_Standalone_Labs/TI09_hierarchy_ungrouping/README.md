# TI09_hierarchy_ungrouping — Hierarchy Ungrouping / Cross-Boundary Optimization

**Category:** Technology-Independent

## Objective
Demonstrate the synthesis behavior corresponding to **Hierarchy Ungrouping / Cross-Boundary Optimization** from the attached RTL synthesis notes.

## Files
- `rtl/before.v` — baseline or unoptimized formulation.
- `rtl/after.v` — explicit optimized formulation.

- `sdc/` — constraints.
- `scripts/run_before.tcl` — baseline Genus run.
- `scripts/run_after.tcl` — optimized Genus run.

- `reports/` — generated area/gates/timing/power/QoR reports.
- `netlist/` — generated mapped netlists.

## Run
```bash
cd TI09_hierarchy_ungrouping
./run_lab.sh
```

## Compare
Check `reports/*_area.rpt`, `*_gates.rpt`, `*_timing.rpt`, and the mapped Verilog in `netlist/`.

## Expected teaching observation
The Tcl attempts the same ungroup -all -flatten concept shown in the notes. If your Genus release uses different ungroup syntax, consult help *ungroup*.

## Important
The supplied `common/lib/teaching.lib` is a synthetic classroom library, not a foundry PDK. It is intended to make synthesis structure and qualitative PPA trends observable. Do not use its absolute PPA values for publication or silicon signoff.
