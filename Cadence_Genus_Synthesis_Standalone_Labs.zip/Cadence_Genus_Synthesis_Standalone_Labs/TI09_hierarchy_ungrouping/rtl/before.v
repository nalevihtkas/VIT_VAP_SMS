module leaf_before(input wire a,b, output wire y);
assign y = a & b;
endmodule
module before_top(input wire a,b, output wire y);
wire n;
leaf_before u_leaf(.a(a),.b(b),.y(n));
assign y = n & 1'b1;
endmodule
