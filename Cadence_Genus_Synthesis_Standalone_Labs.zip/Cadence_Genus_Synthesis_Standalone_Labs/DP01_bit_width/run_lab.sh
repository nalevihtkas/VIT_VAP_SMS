#!/bin/sh
set -e
genus -f scripts/run_before.tcl
genus -f scripts/run_after.tcl
