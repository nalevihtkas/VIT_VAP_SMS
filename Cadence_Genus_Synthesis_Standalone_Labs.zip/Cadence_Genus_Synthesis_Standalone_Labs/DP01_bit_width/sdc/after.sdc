# Combinational teaching constraint
set_max_delay 10.000 -from [all_inputs] -to [all_outputs]
set_load 0.05 [all_outputs]
