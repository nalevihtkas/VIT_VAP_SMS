module before_top(input wire [7:0] a,b, output wire [31:0] y);
wire [31:0] ax={24'd0,a};
wire [31:0] bx={24'd0,b};
assign y=ax+bx;
endmodule
