module after_top(input wire [7:0] a,b, output wire [8:0] y);
assign y={1'b0,a}+{1'b0,b};
endmodule
