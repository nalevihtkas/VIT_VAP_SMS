# DP01_bit_width — Bit-Width Optimization

**Category:** Datapath

## Objective
Demonstrate the synthesis behavior corresponding to **Bit-Width Optimization** from the attached RTL synthesis notes.

## Files
- `rtl/before.v` — baseline or unoptimized formulation.
- `rtl/after.v` — explicit optimized formulation.

- `sdc/` — constraints.
- `scripts/run_before.tcl` — baseline Genus run.
- `scripts/run_after.tcl` — optimized Genus run.

- `reports/` — generated area/gates/timing/power/QoR reports.
- `netlist/` — generated mapped netlists.

## Run
```bash
cd DP01_bit_width
./run_lab.sh
```

## Compare
Check `reports/*_area.rpt`, `*_gates.rpt`, `*_timing.rpt`, and the mapped Verilog in `netlist/`.

## Expected teaching observation
The interface width differs intentionally: two unsigned 8-bit operands require 9 bits for an exact sum.

## Important
The supplied `common/lib/teaching.lib` is a synthetic classroom library, not a foundry PDK. It is intended to make synthesis structure and qualitative PPA trends observable. Do not use its absolute PPA values for publication or silicon signoff.
