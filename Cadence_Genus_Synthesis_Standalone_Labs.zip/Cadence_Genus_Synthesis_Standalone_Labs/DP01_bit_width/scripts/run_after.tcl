source ../common/scripts/common_setup.tcl
set TOP after_top
read_hdl "$LAB_DIR/rtl/after.v"
elaborate $TOP
check_design -unresolved
read_sdc "$LAB_DIR/sdc/after.sdc"

syn_generic
syn_map
syn_opt
basic_reports after
