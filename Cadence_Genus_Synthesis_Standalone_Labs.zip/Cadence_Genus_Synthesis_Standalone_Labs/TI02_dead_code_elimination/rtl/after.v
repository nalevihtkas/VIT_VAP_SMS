module after_top(input wire [7:0] a,b, output wire [7:0] y);
assign y = a+b;
endmodule
