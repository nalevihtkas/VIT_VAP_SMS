module before_top(input wire [7:0] a,b, output wire [7:0] y);
wire [15:0] unused_product;
wire [7:0] useful_sum;
assign unused_product = a*b;
assign useful_sum = a+b;
assign y = useful_sum;
endmodule
