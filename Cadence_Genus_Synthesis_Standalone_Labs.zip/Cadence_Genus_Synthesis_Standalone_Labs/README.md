# Cadence Genus Standalone Synthesis Optimization Labs

This package converts the **technology-independent synthesis**, **technology-dependent synthesis**, and **datapath synthesis** material from the supplied RTL synthesis class notes into standalone Cadence Genus teaching labs.

There are **20 labs** in total.

## Technology-Independent Labs
- `TI01_constant_propagation` — Constant Propagation
- `TI02_dead_code_elimination` — Dead-Code Elimination
- `TI03_boolean_simplification` — Boolean Simplification
- `TI04_redundant_logic` — Redundant Logic Removal
- `TI05_cse` — Common-Subexpression Elimination (CSE)
- `TI06_arithmetic_simplification` — Arithmetic Simplification
- `TI07_mux_simplification` — MUX Simplification
- `TI08_compare_zero` — Comparator-to-Zero Simplification
- `TI09_hierarchy_ungrouping` — Hierarchy Ungrouping / Cross-Boundary Optimization

## Technology-Dependent Labs
- `TD01_complex_cell_mapping` — Complex-Cell Technology Mapping
- `TD02_cell_sizing` — Cell Sizing
- `TD03_buffer_insertion` — Buffer Insertion
- `TD04_logic_balancing` — Gate Restructuring / Logic Balancing
- `TD05_xor_mapping` — XOR Recognition and Mapping

## Datapath Labs
- `DP01_bit_width` — Bit-Width Optimization
- `DP02_resource_sharing` — Resource Sharing
- `DP03_multicycle_reuse` — Multicycle Resource Reuse
- `DP04_pipelining` — Pipelining
- `DP05_retiming` — Retiming
- `DP06_adder_tree` — Adder-Tree Balancing


## Common flow
Each lab uses:

```text
RTL -> elaborate -> constraints -> syn_generic -> syn_map -> syn_opt
    -> area/gates/timing/power/QoR reports -> mapped netlist
```

## Run one lab
```bash
cd TI01_constant_propagation
./run_lab.sh
```

## Run all core labs
From the package root:

```bash
./run_all.sh
```

`DP05_retiming` is special: the source notes themselves state that the exact retiming control depends on the installed Genus release. The package therefore provides a safe retiming template and does not invent a universal command.

## Synthetic teaching library
`common/lib/teaching.lib` contains basic INV/BUF/AND/OR/XOR/MUX/AOI22/DFF cells plus multiple drive strengths where needed. It is **not a real PDK**. Absolute area, delay, and power values are illustrative only.

## Important interpretation
For several technology-independent examples, Genus may optimize the `before.v` formulation into essentially the same mapped structure as `after.v`. That is not a lab failure—it is evidence that `syn_generic` recognized the optimization automatically. Use the mapped netlist and reports to show what Genus removed or restructured.

Technology-dependent results depend on the loaded library and constraints. Datapath sharing/pipelining/retiming also depend on timing goals and synthesis settings.
