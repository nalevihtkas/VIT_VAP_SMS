# Combinational teaching constraint
set_max_delay 1.000 -from [all_inputs] -to [all_outputs]
set_load 0.05 [all_outputs]
set_load 1.00 [all_outputs]
set_max_transition 0.10 [current_design]
