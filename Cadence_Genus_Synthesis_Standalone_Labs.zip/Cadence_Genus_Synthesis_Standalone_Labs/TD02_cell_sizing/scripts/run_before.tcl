source ../common/scripts/common_setup.tcl
set TOP before_top
read_hdl "$LAB_DIR/rtl/before.v"
elaborate $TOP
check_design -unresolved
read_sdc "$LAB_DIR/sdc/before.sdc"
# Baseline: prevent use of the stronger AND2_X4 if command is supported.
catch {set_db lib_cell:AND2_X4 .dont_use true}
syn_generic
syn_map
syn_opt
basic_reports before
