source ../common/scripts/common_setup.tcl
set TOP after_top
read_hdl "$LAB_DIR/rtl/after.v"
elaborate $TOP
check_design -unresolved
read_sdc "$LAB_DIR/sdc/after.sdc"
# Optimized run leaves both AND2_X1 and AND2_X4 available.
# A large output load / tight timing encourages upsizing.
syn_generic
syn_map
syn_opt
basic_reports after
