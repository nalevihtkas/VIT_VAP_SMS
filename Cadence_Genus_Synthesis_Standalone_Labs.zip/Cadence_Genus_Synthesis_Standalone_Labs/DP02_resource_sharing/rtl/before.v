module before_top(input wire [7:0] a,b,c,d, input wire sel, output wire [15:0] y);
wire [15:0] p1=a*b;
wire [15:0] p2=c*d;
assign y=sel?p1:p2;
endmodule
