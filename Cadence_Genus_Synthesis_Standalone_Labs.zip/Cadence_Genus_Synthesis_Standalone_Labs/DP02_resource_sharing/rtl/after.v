module after_top(input wire [7:0] a,b,c,d, input wire sel, output wire [15:0] y);
wire [7:0] op1=sel?a:c;
wire [7:0] op2=sel?b:d;
assign y=op1*op2;
endmodule
