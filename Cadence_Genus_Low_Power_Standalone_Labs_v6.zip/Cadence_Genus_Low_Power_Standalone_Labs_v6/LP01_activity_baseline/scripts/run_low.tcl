set SCRIPT_DIR [file normalize [file dirname [info script]]]
set LAB_DIR    [file normalize "$SCRIPT_DIR/.."]
set COMMON     [file normalize "$LAB_DIR/../common"]
set RPT        "$LAB_DIR/reports"
set NET        "$LAB_DIR/netlist"
file mkdir $RPT
file mkdir $NET
set_db init_hdl_search_path "$LAB_DIR/rtl"
set_db init_lib_search_path "$COMMON/lib"
read_libs "$COMMON/lib/teaching_base.lib"
source "$COMMON/scripts/library_sanity.tcl"

read_hdl "$LAB_DIR/rtl/top.v"
elaborate top
check_design -unresolved
read_sdc "$LAB_DIR/sdc/top.sdc"

puts "Checking required mapping cells before syn_generic..."
puts "If synthesis still reports LBR-171/LBR-172, run these interactively:"
puts {  get_db lib_cells .name}
puts {  get_db lib_cell:teaching_lib/INV_X1 .is_usable}
puts {  get_db lib_cell:teaching_lib/INV_X1 .unusable_reason}
puts {  get_db lib_cell:teaching_lib/AND2_X1 .is_usable}
puts {  get_db lib_cell:teaching_lib/AND2_X1 .unusable_reason}

syn_generic
syn_map
syn_opt

set VCD_FILE "$LAB_DIR/power/low_activity.vcd"
if {![file exists $VCD_FILE]} { error "Missing VCD file: $VCD_FILE" }
if {[catch {read_vcd $VCD_FILE -vcd_scope tb_top/dut} vcd_msg]} {
  error "VCD annotation failed for $VCD_FILE: $vcd_msg"
} else {
  puts "VCD annotation successful: $VCD_FILE"
}
report timing > "$RPT/low_timing.rpt"
report area   > "$RPT/low_area.rpt"
report gates  > "$RPT/low_gates.rpt"
report power  > "$RPT/low_power.rpt"
report qor    > "$RPT/low_qor.rpt"
write_hdl     > "$NET/low_mapped.v"
write_sdc     > "$NET/low_mapped.sdc"
puts "DONE: low"
exit
