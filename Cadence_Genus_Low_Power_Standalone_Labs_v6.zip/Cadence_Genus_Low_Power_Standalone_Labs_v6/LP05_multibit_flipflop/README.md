# LP05 — Multi-Bit Flip-Flop Mapping

A technology-dependent structural teaching lab. `before.v` instantiates four single-bit `DFF_X1` cells. `after.v` instantiates one `DFF4_X1` teaching cell. The Liberty model gives the MBFF a smaller aggregate clock capacitance and area than four individual DFFs.

With a real PDK, prefer Genus/physical-design MBFF mapping rather than hand-instantiating a synthetic cell.


## v6 correction — zero power in the AFTER MBFF run

The v3/v4/v5 `teaching_base.lib` accidentally omitted `DFF4_X1` even though
`rtl/after.v` instantiated it. The old `teaching.lib` contained the cell, but
the LP05 Tcl script loads `teaching_base.lib`. On Genus this can leave the MBFF
as an unresolved/black-box-like object or otherwise prevent proper power
characterization, which can lead to a misleading zero-power report.

v6 adds a fully characterized teaching `DFF4_X1` to `teaching_base.lib`,
including:
- four FF state definitions,
- clock capacitance,
- D-pin setup/hold constraints,
- CLK-to-Q timing arcs,
- output transitions,
- area and leakage power.

Before accepting the power report, verify:
```tcl
get_db lib_cell:teaching_lib/DFF4_X1 .is_usable
get_db lib_cell:teaching_lib/DFF4_X1 .unusable_reason
```

Also open `reports/after_gates.rpt` or `reports/after_cells_pre_power.rpt` and
confirm that `DFF4_X1` is present in the mapped design.

A zero total power result is not a valid expected MBFF result. The AFTER design
should normally have non-zero leakage and dynamic/switching power. MBFF should
reduce clock capacitance/power relative to four single-bit FFs, not reduce power
to exactly zero.
