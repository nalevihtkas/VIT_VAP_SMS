# LP02 — Clock Gating

`before.v` uses a conventional enable-controlled register bank. `after.v` instantiates the synthetic teaching `ICG_X1` cell so the clock to the 64-bit bank stops when `enable=0`. The included activity keeps the block idle most cycles.

For a real PDK, replace `ICG_X1` with the characterized ICG cell or use the exact Genus clock-gating insertion control supported by your release.


## Important v5 correction: why the old clock-gating lab could show higher power

The earlier lab used the **same top-level VCD** for both runs. That VCD contained
`clk`, `enable`, and `d`, but it did **not contain the internal gated clock `gclk`**.
On older Genus releases, activity on a derived clock is not guaranteed to be
propagated from the manually instantiated teaching `ICG_X1` exactly as intended.
The tool could therefore assign too much activity to `gclk`, while the AFTER
design also contains the extra ICG cell. In that situation total reported power
can increase even though the conceptual clock-gating architecture is correct.

v5 fixes this by using two activity files:

- `power/before_activity.vcd`
- `power/after_activity.vcd`

The AFTER VCD explicitly contains `tb_top/dut/gclk`. The root `clk` toggles every
10 ns in both experiments, while `enable` is asserted only one cycle out of ten.
Therefore `gclk` toggles only during approximately 10% of the cycles.

### What to compare

Do not look only at `Total Power`. Compare:

1. clock/gated-clock activity,
2. switching power,
3. internal power,
4. leakage power,
5. total power,
6. area.

Clock gating adds ICG area/leakage. It only wins dynamically if enough downstream
clock capacitance is disabled for enough time.

### Expected qualitative result for this teaching case

`enable` duty cycle ≈ 10%, so `gclk` activity should be much lower than `clk`.
The BEFORE and AFTER designs have the same 64-bit register bank; AFTER additionally
has the ICG. Dynamic clock-related power should reduce if the Liberty/VCD activity
is honored, while area and leakage may rise slightly because of the ICG.
