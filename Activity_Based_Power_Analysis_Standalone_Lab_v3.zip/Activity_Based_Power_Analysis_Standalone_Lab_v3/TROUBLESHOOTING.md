# Troubleshooting

## MAP-2: "requires an async clear flop"

Cause:
The RTL requires an asynchronous reset FF but the teaching library only contains
a simple positive-edge DFF.

v3 fix:
The DUT uses synchronous reset:

```verilog
always @(posedge clk)
```

with:

```verilog
if (!rst_n)
```

inside the clocked block.

Expected result:
`syn_generic`, `syn_map`, and `syn_opt` should no longer stop because of an
async-clear flop requirement.

If a mapping error remains, at the Genus prompt inspect:

```tcl
get_db lib_cells .name
get_db lib_cell:teaching_lib/DFF_X1 .is_usable
get_db lib_cell:teaching_lib/DFF_X1 .unusable_reason
```
