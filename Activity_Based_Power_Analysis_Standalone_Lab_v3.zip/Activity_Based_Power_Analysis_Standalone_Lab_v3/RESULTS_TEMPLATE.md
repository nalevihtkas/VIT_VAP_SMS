# Results Template

## A. Clock Activity Experiment

Keep data nearly constant. Compare only clock activity.

| Metric | LOW CLOCK (20 MHz VCD) | HIGH CLOCK (200 MHz VCD) | Expected |
|---|---:|---:|---|
| Cell area | | | Same/nearly same |
| Gate count | | | Same/nearly same |
| Internal power | | | Higher for high clock |
| Switching power | | | Higher for high clock |
| Leakage power | | | Similar |
| Total power | | | Higher for high clock |

## B. Data Activity Experiment

Clock is fixed at 100 MHz in both VCDs.

| Metric | LOW DATA | HIGH DATA | Expected |
|---|---:|---:|---|
| Cell area | | | Same/nearly same |
| Gate count | | | Same/nearly same |
| Internal power | | | Higher for high data |
| Switching power | | | Higher for high data |
| Leakage power | | | Similar |
| Total power | | | Higher for high data |
