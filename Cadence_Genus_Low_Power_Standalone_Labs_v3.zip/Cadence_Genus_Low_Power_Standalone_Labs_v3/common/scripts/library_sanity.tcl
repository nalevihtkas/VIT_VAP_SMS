# Library sanity helper for Cadence Genus Common UI.
# It clears avoid/preserve flags that can make otherwise valid teaching cells unavailable.
set all_lcells [get_db lib_cells]
foreach lc $all_lcells {
  catch {set_db $lc .avoid false}
  catch {set_db $lc .preserve false}
}

puts "========== LIBRARY SANITY =========="
puts "Libraries:"
catch {puts [get_db libraries .name]}
puts "Library cells:"
catch {puts [get_db lib_cells .name]}
puts "===================================="
