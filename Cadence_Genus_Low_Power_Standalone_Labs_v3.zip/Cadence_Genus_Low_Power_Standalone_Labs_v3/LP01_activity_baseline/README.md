# LP01 — Low vs High Switching Activity

## Purpose
Demonstrate that **the same synthesized hardware** can consume different dynamic power because switching activity (alpha) changes.

- `low_activity.vcd`: `enable=1` after reset, but `a` and `b` change only once every 10 clock cycles.
- `high_activity.vcd`: `enable=1` after reset, and `a`/`b` change every clock cycle with intentionally large bit transitions.

Keeping `enable=1` in both cases avoids confusing *clock/data enable duty cycle* with *operand switching activity*. The RTL, clock period (10 ns), constraints and library are identical. Only operand toggle rate differs.

Run:
```bash
genus -f scripts/run_low.tcl
genus -f scripts/run_high.tcl
```
Compare `reports/low_power.rpt` and `reports/high_power.rpt`. Area and timing should be essentially unchanged; switching/dynamic power should be higher in the high-activity run.

## LBR-171 / LBR-172 diagnostic

If `syn_generic` says there is no usable inverter/basic gate, the problem is the Liberty
mapping library, not the RTL or SDC. v3 contains a strengthened `teaching_base.lib`.

At the Genus prompt, after `read_libs`, use:

```tcl
get_db libraries .name
get_db lib_cells .name
get_db lib_cell:teaching_lib/INV_X1 .is_usable
get_db lib_cell:teaching_lib/INV_X1 .unusable_reason
get_db lib_cell:teaching_lib/AND2_X1 .is_usable
get_db lib_cell:teaching_lib/AND2_X1 .unusable_reason
```

If your release names the library object differently, use the name printed by
`get_db libraries .name`.
