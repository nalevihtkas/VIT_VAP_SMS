#!/bin/sh
set -e

rm -f vcd/*.vcd

echo "=== Simulating LOW CLOCK activity ==="
xrun -64bit -clean -access +rwc \
  rtl/activity_power_top.v tb/tb_clk_low.v

echo "=== Simulating HIGH CLOCK activity ==="
xrun -64bit -clean -access +rwc \
  rtl/activity_power_top.v tb/tb_clk_high.v

echo "=== Simulating LOW DATA activity ==="
xrun -64bit -clean -access +rwc \
  rtl/activity_power_top.v tb/tb_data_low.v

echo "=== Simulating HIGH DATA activity ==="
xrun -64bit -clean -access +rwc \
  rtl/activity_power_top.v tb/tb_data_high.v

echo
echo "Generated VCD files:"
ls -lh vcd/*.vcd
