#!/bin/sh
set -e

rm -f vcd/*.vcd
rm -f sim_*.out

for CASE in clk_low clk_high data_low data_high
do
  echo "=== Simulating ${CASE} ==="
  iverilog -g2012 -o sim_${CASE}.out \
    rtl/activity_power_top.v tb/tb_${CASE}.v
  vvp sim_${CASE}.out
done

echo
echo "Generated VCD files:"
ls -lh vcd/*.vcd
