#!/bin/sh
set -e

echo "STEP 1: Simulation -> generate VCD"
./scripts/run_sim_xrun.sh

echo
echo "STEP 2: Genus synthesis + VCD-based power analysis"
./scripts/run_genus_all.sh

echo
echo "Experiment complete."
