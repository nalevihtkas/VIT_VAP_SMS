# This file is informational: Genus is normally launched separately per lab.
puts "Use run_all.sh in a shell, or run each LPxx/scripts/run_*.tcl with genus -f."
exit
