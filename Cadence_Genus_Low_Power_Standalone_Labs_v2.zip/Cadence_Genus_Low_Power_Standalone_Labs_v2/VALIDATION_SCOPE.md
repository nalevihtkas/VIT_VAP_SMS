# Validation Scope — Important

## Quantitatively runnable with the synthetic teaching Liberty
LP01 Activity baseline, LP02 Clock gating structural comparison, LP03 Operand isolation, LP04 Data gating, LP05 MBFF structural comparison, LP06 Multi-Vt structural comparison.

The numerical PPA values are **illustrative only** because the Liberty is synthetic. They are suitable for teaching trends, not publication or silicon prediction.

## Structurally runnable, but true power-intent behavior needs a real low-power PDK/library
LP07 Power gating, LP08 Isolation, LP09 Retention, LP10 Multi-voltage/level shifting. Their before/after structural RTL and synthetic special cells can be synthesized in Genus. However, true UPF insertion, switched-supply leakage, retention supply behavior, voltage-specific delay/power, and automatic level-shifter/isolation insertion cannot be guaranteed from a synthetic generic Liberty. Those require your installed Genus/IEEE-1801 flow and licensed power-aware libraries.

`run_lab.sh` intentionally runs only the safe core before/after synthesis. Optional UPF experiments must be launched separately after adapting the UPF to the installed Genus release and PDK.
