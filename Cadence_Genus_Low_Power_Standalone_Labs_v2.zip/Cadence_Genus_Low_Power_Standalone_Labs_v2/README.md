# Cadence Genus Low-Power Synthesis — Standalone Teaching Labs

This package contains ten independent low-power synthesis labs derived from the low-power concepts in the supplied class notes.

## Important note about the included library

`common/lib/teaching.lib` is an original **teaching-only synthetic Liberty library** included so the examples are self-contained. It is **not** a foundry/PDK library and its area, delay, leakage, voltage and power numbers are illustrative only. Never use its numerical results for publication or silicon sign-off.

The package is designed so the **core Genus synthesis flows are runnable without a proprietary .lib**. For real lab/project results, replace `common/lib/teaching.lib` with the Liberty libraries from your Cadence/PDK installation and update the low-power cell names/UPF commands accordingly.

Power-intent behavior (power switch, isolation, retention, voltage domains) varies with Cadence Genus version, IEEE 1801/UPF version, license, and library power-pin characterization. LP07–LP10 therefore include:

1. a core Genus synthesis run that is self-contained and demonstrates the structure with teaching cells; and
2. an `intent/*.upf` file plus an optional `run_with_upf.tcl` that attempts to load UPF when the installed Genus supports the expected commands, but does not abort the core lab if that syntax is unavailable.

## Labs

| Lab | Concept | Comparison |
|---|---|---|
| LP01 | Activity-based power baseline | low activity vs high activity |
| LP02 | Clock gating | enable FF bank vs ICG-gated FF bank |
| LP03 | Operand isolation | continuously toggling multiplier vs clamped operands |
| LP04 | Data gating | continuously updated register vs held data input |
| LP05 | Multi-bit flip-flop | 4 single-bit DFFs vs one 4-bit MBFF teaching cell |
| LP06 | Multi-Vt | all-LVT mapping vs HVT on noncritical logic |
| LP07 | Power gating | always-on model vs sleep-controlled power-switch model + UPF template |
| LP08 | Isolation | direct powered-domain output vs clamp-to-0 isolation cell |
| LP09 | Retention | ordinary FF vs retention FF teaching cell + UPF template |
| LP10 | Multi-voltage / level shifting | direct crossing vs level-shifter teaching cell + UPF template |

## Requirements

- Cadence Genus available as `genus` in PATH.
- Bash shell for `run_all.sh` (optional; individual Tcl files can be run manually).
- No external simulator is required for the included power activity experiments because representative VCD files are already supplied.

## Run one lab

Example:

```bash
cd LP03_operand_isolation
./run_lab.sh
```

Or directly:

```bash
genus -f scripts/run_before.tcl
genus -f scripts/run_after.tcl
```

## Run all core labs

```bash
chmod +x run_all.sh
./run_all.sh
```

## Where results appear

Each lab writes reports into its own `reports/` directory and mapped netlists into `netlist/`.

Typical reports:

- `*_area.rpt`
- `*_gates.rpt`
- `*_timing.rpt`
- `*_power.rpt`
- `*_qor.rpt`

## Recommended validation rule

For every lab compare three things:

1. **Function** — before/after RTL has the intended behavior.
2. **Structure** — mapped netlist/cell report contains the expected low-power structure.
3. **PPA** — compare area, timing, switching/internal power, leakage and total power.

## Converting to your real PDK

Replace:

```tcl
read_libs $COMMON/lib/teaching.lib
```

with your real library/libraries, for example:

```tcl
read_libs {slow.lib}
```

For Multi-Vt:

```tcl
read_libs {slow_lvt.lib slow_rvt.lib slow_hvt.lib}
```

Then replace teaching cell names such as `ICG_X1`, `DFF4_X1`, `ISO0_X1`, `RETDFF_X1`, and `LS_X1` with the matching cells from your characterized library if you use the structural after examples.


## v2 corrections
- LP01 now uses true low/high operand switching with the same enable condition.
- Separate LVT/RVT/HVT Liberty files are included and LP06 explicitly loads them.
- LP06 VCD clock is corrected to 2 ns to match its SDC.
- VCD annotation failures are fatal, preventing misleading default-activity reports.
- `run_lab.sh` no longer launches optional UPF scripts accidentally.
- LP07 hierarchy now contains `u_core`, matching the UPF domain example.
- See `VALIDATION_SCOPE.md` for what can and cannot be proven with a synthetic library.
