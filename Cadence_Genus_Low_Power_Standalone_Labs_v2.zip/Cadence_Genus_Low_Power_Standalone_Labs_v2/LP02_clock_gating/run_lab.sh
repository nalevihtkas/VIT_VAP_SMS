#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "=== scripts/run_before.tcl ==="
genus -f "scripts/run_before.tcl"
echo "=== scripts/run_after.tcl ==="
genus -f "scripts/run_after.tcl"
