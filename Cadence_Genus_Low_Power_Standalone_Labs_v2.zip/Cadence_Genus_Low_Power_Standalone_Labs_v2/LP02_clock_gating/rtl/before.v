module cg_before(input clk,input rst_n,input enable,input [63:0] d,output reg [63:0] q);
always @(posedge clk) begin
  if(!rst_n) q <= 64'd0;
  else if(enable) q <= d;
end
endmodule
