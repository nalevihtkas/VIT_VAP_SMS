module cg_after(input clk,input rst_n,input enable,input [63:0] d,output reg [63:0] q);
wire gclk;
ICG_X1 u_icg(.CLK(clk),.EN(enable),.GCLK(gclk));
always @(posedge gclk) begin
  if(!rst_n) q <= 64'd0;
  else q <= d;
end
endmodule
