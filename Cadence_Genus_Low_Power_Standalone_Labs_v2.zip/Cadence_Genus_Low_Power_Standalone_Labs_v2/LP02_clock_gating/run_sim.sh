#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v iverilog >/dev/null 2>&1; then
  echo "iverilog not installed; supplied VCD is already available for Genus."
  exit 0
fi
for tb in tb/*.v; do
  [ -f "$tb" ] || continue
  base=$(basename "$tb" .v)
  case "$base" in *before*) rtl=rtl/before.v ;; *after*) rtl=rtl/after.v ;; *) continue ;; esac
  tmp=$(mktemp -d)
  iverilog -g2012 -o "$tmp/sim.out" ../common/lib/teaching_cells.v "$rtl" "$tb"
  (cd "$tmp" && vvp sim.out)
  if [ -f "$tmp/activity.vcd" ]; then cp "$tmp/activity.vcd" "power/${base}_generated.vcd"; fi
  rm -rf "$tmp"
  echo "Generated power/${base}_generated.vcd (supplied activity.vcd left untouched)"
done
