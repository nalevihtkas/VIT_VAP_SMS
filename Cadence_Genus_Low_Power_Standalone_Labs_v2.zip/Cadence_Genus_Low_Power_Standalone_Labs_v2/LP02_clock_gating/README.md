# LP02 — Clock Gating

`before.v` uses a conventional enable-controlled register bank. `after.v` instantiates the synthetic teaching `ICG_X1` cell so the clock to the 64-bit bank stops when `enable=0`. The included activity keeps the block idle most cycles.

For a real PDK, replace `ICG_X1` with the characterized ICG cell or use the exact Genus clock-gating insertion control supported by your release.
