`timescale 1ns/1ps
module tb_top;reg clk=0;reg[7:0]a=0,b=0;wire y_fast,y_slow;mvt_before dut(.clk(clk),.a(a),.b(b),.y_fast(y_fast),.y_slow(y_slow));always #1 clk=~clk;initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top);repeat(100)begin @(negedge clk);a=$random;b=$random;end #2 $finish;end endmodule
