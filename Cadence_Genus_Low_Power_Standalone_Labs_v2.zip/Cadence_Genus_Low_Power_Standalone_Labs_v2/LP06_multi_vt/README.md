# LP06 — Multi-Vt (LVT/RVT/HVT)

This revision contains **separate Liberty files**:
- `../common/lib/teaching_lvt.lib` — `AND2_LVT` (fast, high leakage)
- `../common/lib/teaching_rvt.lib` — `AND2_RVT` (medium)
- `../common/lib/teaching_hvt.lib` — `AND2_HVT` (slower, low leakage)
- `../common/lib/teaching_base.lib` — common cells and sequential/special cells

The before/after RTL is intentionally structural so the teaching result is deterministic: the critical chain remains LVT, while one noncritical cell changes from LVT to HVT. This demonstrates the timing/leakage trade-off without relying on release-specific automatic Vt optimization settings.

The SDC clock period is 2 ns, and the supplied VCD now also uses a 2 ns clock, so power activity and timing constraints are consistent.
