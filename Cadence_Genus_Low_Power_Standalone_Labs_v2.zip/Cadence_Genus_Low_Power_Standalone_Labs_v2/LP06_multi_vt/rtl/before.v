module mvt_before(input clk,input [7:0] a,b,output reg y_fast,output reg y_slow);
wire f0,f1,f2,f3,s0;
AND2_LVT a0(.A(a[0]),.B(b[0]),.Y(f0));
AND2_LVT a1(.A(f0),.B(a[1]),.Y(f1));
AND2_LVT a2(.A(f1),.B(b[1]),.Y(f2));
AND2_LVT a3(.A(f2),.B(a[2]),.Y(f3));
AND2_LVT s1(.A(a[7]),.B(b[7]),.Y(s0));
always @(posedge clk) begin y_fast<=f3; y_slow<=s0; end
endmodule
