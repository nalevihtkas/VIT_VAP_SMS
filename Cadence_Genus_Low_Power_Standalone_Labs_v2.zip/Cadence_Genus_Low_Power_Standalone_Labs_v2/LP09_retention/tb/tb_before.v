`timescale 1ns/1ps
module tb_top;reg clk=0,d=0,save=0,restore=0;wire q;ret_before dut(.clk(clk),.d(d),.save(save),.restore(restore),.q(q));always #5 clk=~clk;integer i;initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top);for(i=0;i<50;i=i+1)begin @(negedge clk);d=$random;save=(i==10);restore=(i==20);end #10 $finish;end endmodule
