module ret_after(input clk,input d,input save,input restore,output q);
RETDFF_X1 u_rff(.CLK(clk),.D(d),.SAVE(save),.RESTORE(restore),.Q(q));
endmodule
