module ret_before(input clk,input d,input save,input restore,output q);
DFF_X1 u_ff(.CLK(clk),.D(d),.Q(q));
endmodule
