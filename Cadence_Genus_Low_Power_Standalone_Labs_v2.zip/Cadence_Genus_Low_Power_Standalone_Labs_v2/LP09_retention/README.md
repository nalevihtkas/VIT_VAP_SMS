# LP09 — Retention

`before.v` uses an ordinary DFF teaching cell. `after.v` uses `RETDFF_X1` with SAVE and RESTORE controls. The cell model is for classroom structural demonstration only. A real implementation must use a retention-capable library cell and UPF retention supply/control definitions.
