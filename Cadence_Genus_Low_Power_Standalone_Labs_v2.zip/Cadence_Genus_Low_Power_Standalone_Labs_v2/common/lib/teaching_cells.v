`timescale 1ns/1ps
module BUF_X1(input A, output Y); assign Y=A; endmodule
module INV_X1(input A, output Y); assign Y=~A; endmodule
module AND2_X1(input A,B, output Y); assign Y=A&B; endmodule
module OR2_X1(input A,B, output Y); assign Y=A|B; endmodule
module XOR2_X1(input A,B, output Y); assign Y=A^B; endmodule
module MUX2_X1(input A,B,S, output Y); assign Y=S?B:A; endmodule
module AND2_LVT(input A,B, output Y); assign Y=A&B; endmodule
module AND2_RVT(input A,B, output Y); assign Y=A&B; endmodule
module AND2_HVT(input A,B, output Y); assign Y=A&B; endmodule
module DFF_X1(input CLK,D, output reg Q); always @(posedge CLK) Q<=D; endmodule
module ICG_X1(input CLK,EN, output GCLK); assign GCLK=CLK&EN; endmodule
module DFF4_X1(input CLK,input D0,D1,D2,D3,output reg Q0,Q1,Q2,Q3);
  always @(posedge CLK) begin Q0<=D0;Q1<=D1;Q2<=D2;Q3<=D3; end
endmodule
module ISO0_X1(input A,ISO_N,output Y); assign Y=A&ISO_N; endmodule
module RETDFF_X1(input CLK,D,SAVE,RESTORE,output reg Q); reg saved;
  initial begin Q=0; saved=0; end
  always @(posedge CLK) begin
    if (SAVE) saved <= Q;
    if (RESTORE) Q <= saved; else Q <= D;
  end
endmodule
module LS_X1(input A,output Y); assign Y=A; endmodule
module POWER_SWITCH_X1(input SLEEP,output PWR_OK); assign PWR_OK=~SLEEP; endmodule
