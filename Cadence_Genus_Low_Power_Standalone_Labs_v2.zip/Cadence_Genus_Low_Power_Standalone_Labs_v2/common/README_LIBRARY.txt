Synthetic classroom Liberty set (non-proprietary, illustrative only).

teaching_base.lib  : common logic, DFF, ICG, MBFF, isolation, retention, level-shifter and power-switch teaching proxy cells
teaching_lvt.lib   : AND2_LVT, fast/high-leakage example
teaching_rvt.lib   : AND2_RVT, medium example
teaching_hvt.lib   : AND2_HVT, slower/low-leakage example
teaching.lib       : legacy combined copy retained for reference; v2 Tcl scripts do not rely on it
teaching_cells.v   : functional simulation models

These files are designed to demonstrate relative trends. Replace with your licensed PDK libraries for real PPA.
