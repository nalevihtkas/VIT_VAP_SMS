# Report Checklist

For each before/after pair record:

| Metric | Before | After | Interpretation |
|---|---:|---:|---|
| Cell area | | | area overhead/saving |
| Gate/cell count | | | structural change |
| Critical path delay | | | timing impact |
| WNS | | | timing closure impact |
| Internal power | | | cell internal switching |
| Switching power | | | net capacitance switching |
| Leakage power | | | static leakage |
| Total power | | | overall result |

Also inspect the mapped netlist for the expected structural cell, where applicable:

- LP02: `ICG_X1`
- LP05: `DFF4_X1`
- LP06: `AND2_LVT` / `AND2_HVT`
- LP07: `POWER_SWITCH_X1` teaching proxy
- LP08: `ISO0_X1`
- LP09: `RETDFF_X1`
- LP10: `LS_X1`
