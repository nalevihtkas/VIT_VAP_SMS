#!/usr/bin/env python3
from pathlib import Path
import re,sys
ROOT=Path(__file__).resolve().parents[1]
errs=[]; warns=[]
required_libs=['teaching_base.lib','teaching_lvt.lib','teaching_rvt.lib','teaching_hvt.lib','teaching_cells.v']
for n in required_libs:
    if not (ROOT/'common/lib'/n).exists(): errs.append(f'Missing library/model: {n}')
# brace balance for Liberty files and required cells
req_cells={'teaching_base.lib':['AND2_X1','DFF_X1','ICG_X1','DFF4_X1','ISO0_X1','RETDFF_X1','LS_X1','POWER_SWITCH_X1'],
           'teaching_lvt.lib':['AND2_LVT'],'teaching_rvt.lib':['AND2_RVT'],'teaching_hvt.lib':['AND2_HVT']}
for fn,cells in req_cells.items():
    p=ROOT/'common/lib'/fn
    if not p.exists(): continue
    txt=p.read_text()
    if txt.count('{')!=txt.count('}'): errs.append(f'Unbalanced braces in {fn}')
    for c in cells:
        if not re.search(r'cell\s*\('+re.escape(c)+r'\)',txt): errs.append(f'{fn}: missing {c}')
# lab files / module-elaborate checks
for lab in sorted(ROOT.glob('LP*')):
    if not lab.is_dir(): continue
    for p in [lab/'sdc/top.sdc',lab/'run_lab.sh']:
        if not p.exists(): errs.append(f'{lab.name}: missing {p.relative_to(lab)}')
    for tcl in (lab/'scripts').glob('run_*.tcl'):
        txt=tcl.read_text()
        mrtl=re.search(r'read_hdl\s+"\$LAB_DIR/rtl/([^\"]+)"',txt)
        melab=re.search(r'elaborate\s+(\w+)',txt)
        if mrtl:
            rp=lab/'rtl'/mrtl.group(1)
            if not rp.exists(): errs.append(f'{lab.name}/{tcl.name}: missing RTL {rp.name}')
            elif melab and not re.search(r'\bmodule\s+'+re.escape(melab.group(1))+r'\b',rp.read_text()):
                errs.append(f'{lab.name}/{tcl.name}: elaborate {melab.group(1)} not found in {rp.name}')
        for vf in re.findall(r'power/([^\"]+\.vcd)',txt):
            if not (lab/'power'/vf).exists(): errs.append(f'{lab.name}/{tcl.name}: missing VCD {vf}')
# LP01 activity sanity
lo=(ROOT/'LP01_activity_baseline/power/low_activity.vcd').read_text(); hi=(ROOT/'LP01_activity_baseline/power/high_activity.vcd').read_text()
def value_changes(txt,sym): return sum(1 for line in txt.splitlines() if line.endswith(' '+sym) or (len(sym)==1 and line.endswith(sym) and line[:1] in '01xz'))
# vector symbols are $ and %
lo_ops=value_changes(lo,'$')+value_changes(lo,'%'); hi_ops=value_changes(hi,'$')+value_changes(hi,'%')
if hi_ops <= lo_ops*3: errs.append(f'LP01 high/low operand activity separation too small: low={lo_ops}, high={hi_ops}')
# LP06 clock sanity: look for clock transitions every 1ns and SDC 2ns
sdc=(ROOT/'LP06_multi_vt/sdc/top.sdc').read_text()
if '-period 2.000' not in sdc: warns.append('LP06 SDC period is not 2.000 ns')
print(f'Package: {ROOT}')
print(f'LP01 operand vector change records: low={lo_ops}, high={hi_ops}')
if warns:
    print('WARNINGS:'); [print(' -',w) for w in warns]
if errs:
    print('ERRORS:'); [print(' -',e) for e in errs]; sys.exit(1)
print('STATIC CHECK: PASS')
print('Note: this verifies package consistency, not execution inside a specific installed Genus version/license.')
