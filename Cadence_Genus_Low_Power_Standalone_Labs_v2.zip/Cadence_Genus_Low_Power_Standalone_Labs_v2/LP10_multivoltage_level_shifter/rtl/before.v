module mv_before(input clk,input [7:0] a,b,output reg y);
wire cross = ^(a+b);
always @(posedge clk) y<=cross;
endmodule
