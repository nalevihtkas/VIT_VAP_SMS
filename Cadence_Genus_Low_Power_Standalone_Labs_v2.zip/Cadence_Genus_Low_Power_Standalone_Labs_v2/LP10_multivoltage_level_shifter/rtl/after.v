module mv_after(input clk,input [7:0] a,b,output reg y);
wire cross = ^(a+b);
wire shifted;
LS_X1 u_ls(.A(cross),.Y(shifted));
always @(posedge clk) y<=shifted;
endmodule
