`timescale 1ns/1ps
module tb_top;reg clk=0;reg[7:0]a=0,b=0;wire y;mv_before dut(.clk(clk),.a(a),.b(b),.y(y));always #5 clk=~clk;initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top);repeat(100)begin @(negedge clk);a=$random;b=$random;end #10 $finish;end endmodule
