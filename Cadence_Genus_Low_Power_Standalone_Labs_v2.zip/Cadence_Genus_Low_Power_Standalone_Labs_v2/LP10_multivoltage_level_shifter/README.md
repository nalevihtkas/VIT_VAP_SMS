# LP10 — Multi-Voltage / Level Shifter

`before.v` has a direct logic-domain crossing. `after.v` inserts the synthetic `LS_X1` level-shifter cell. The UPF template documents two conceptual voltage domains. Real voltage-dependent power requires characterized libraries/operating conditions for each voltage.
