#!/usr/bin/env bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "===== LP01_activity_baseline ====="
(cd "$ROOT/LP01_activity_baseline" && ./run_lab.sh)
echo "===== LP02_clock_gating ====="
(cd "$ROOT/LP02_clock_gating" && ./run_lab.sh)
echo "===== LP03_operand_isolation ====="
(cd "$ROOT/LP03_operand_isolation" && ./run_lab.sh)
echo "===== LP04_data_gating ====="
(cd "$ROOT/LP04_data_gating" && ./run_lab.sh)
echo "===== LP05_multibit_flipflop ====="
(cd "$ROOT/LP05_multibit_flipflop" && ./run_lab.sh)
echo "===== LP06_multi_vt ====="
(cd "$ROOT/LP06_multi_vt" && ./run_lab.sh)
echo "===== LP07_power_gating ====="
(cd "$ROOT/LP07_power_gating" && ./run_lab.sh)
echo "===== LP08_isolation ====="
(cd "$ROOT/LP08_isolation" && ./run_lab.sh)
echo "===== LP09_retention ====="
(cd "$ROOT/LP09_retention" && ./run_lab.sh)
echo "===== LP10_multivoltage_level_shifter ====="
(cd "$ROOT/LP10_multivoltage_level_shifter" && ./run_lab.sh)
echo "All core lab scripts finished."
