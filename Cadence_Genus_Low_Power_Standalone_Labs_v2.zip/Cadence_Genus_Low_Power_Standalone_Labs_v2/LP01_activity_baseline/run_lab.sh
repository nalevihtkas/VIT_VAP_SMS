#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
echo "=== scripts/run_low.tcl ==="
genus -f "scripts/run_low.tcl"
echo "=== scripts/run_high.tcl ==="
genus -f "scripts/run_high.tcl"
