module top(input clk,input rst_n,input enable,input [7:0] a,b,output reg [15:0] result);
always @(posedge clk) begin
  if(!rst_n) result <= 16'd0;
  else if(enable) result <= a*b;
end
endmodule
