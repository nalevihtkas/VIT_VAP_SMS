`timescale 1ns/1ps
module tb_top;
  reg clk=0, rst_n=0, enable=0;
  reg [7:0] a=8'h00, b=8'hFF;
  wire [15:0] result;
  integer i;
  top dut(.clk(clk),.rst_n(rst_n),.enable(enable),.a(a),.b(b),.result(result));
  always #5 clk = ~clk;
  initial begin
    $dumpfile("high_activity.vcd");
    $dumpvars(0,tb_top);
    #20 rst_n=1; enable=1;
    for(i=0;i<100;i=i+1) begin
      @(negedge clk);
      // HIGH switching: operands change every cycle with large bit changes.
      a <= ~a;
      b <= {b[6:0],b[7]} ^ 8'hA5;
    end
    #20 $finish;
  end
endmodule
