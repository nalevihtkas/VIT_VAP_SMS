`timescale 1ns/1ps
module tb_top;
  reg clk=0, rst_n=0, enable=0;
  reg [7:0] a=8'h00, b=8'h00;
  wire [15:0] result;
  integer i;
  top dut(.clk(clk),.rst_n(rst_n),.enable(enable),.a(a),.b(b),.result(result));
  always #5 clk = ~clk;
  initial begin
    $dumpfile("low_activity.vcd");
    $dumpvars(0,tb_top);
    #20 rst_n=1; enable=1;
    for(i=0;i<100;i=i+1) begin
      @(negedge clk);
      // LOW switching: operands change only once every 10 clock cycles.
      if ((i % 10)==0) begin
        a <= a + 8'h13;
        b <= b + 8'h29;
      end
    end
    #20 $finish;
  end
endmodule
