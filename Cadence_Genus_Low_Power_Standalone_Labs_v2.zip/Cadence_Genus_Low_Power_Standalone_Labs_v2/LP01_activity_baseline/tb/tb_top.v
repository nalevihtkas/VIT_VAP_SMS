`timescale 1ns/1ps
// Reference-only baseline testbench. For LP01 use tb_low.v and tb_high.v.
module tb_top_reference;
  reg clk=0,rst_n=0,enable=1; reg [7:0] a=0,b=0; wire [15:0] result;
  top dut(.clk(clk),.rst_n(rst_n),.enable(enable),.a(a),.b(b),.result(result));
  always #5 clk=~clk;
endmodule
