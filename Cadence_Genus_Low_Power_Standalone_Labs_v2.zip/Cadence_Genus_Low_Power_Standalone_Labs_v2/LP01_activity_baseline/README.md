# LP01 — Low vs High Switching Activity

## Purpose
Demonstrate that **the same synthesized hardware** can consume different dynamic power because switching activity (alpha) changes.

- `low_activity.vcd`: `enable=1` after reset, but `a` and `b` change only once every 10 clock cycles.
- `high_activity.vcd`: `enable=1` after reset, and `a`/`b` change every clock cycle with intentionally large bit transitions.

Keeping `enable=1` in both cases avoids confusing *clock/data enable duty cycle* with *operand switching activity*. The RTL, clock period (10 ns), constraints and library are identical. Only operand toggle rate differs.

Run:
```bash
genus -f scripts/run_low.tcl
genus -f scripts/run_high.tcl
```
Compare `reports/low_power.rpt` and `reports/high_power.rpt`. Area and timing should be essentially unchanged; switching/dynamic power should be higher in the high-activity run.
