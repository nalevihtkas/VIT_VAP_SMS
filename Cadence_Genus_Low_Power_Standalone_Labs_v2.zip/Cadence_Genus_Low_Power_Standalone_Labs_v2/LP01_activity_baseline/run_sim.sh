#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
if ! command -v iverilog >/dev/null 2>&1; then
  echo "iverilog not installed; supplied low_activity.vcd and high_activity.vcd are already available."
  exit 0
fi
for mode in low high; do
  tmp=$(mktemp -d)
  iverilog -g2012 -o "$tmp/sim.out" rtl/top.v "tb/tb_${mode}.v"
  (cd "$tmp" && vvp sim.out)
  cp "$tmp/${mode}_activity.vcd" "power/${mode}_activity_generated.vcd"
  rm -rf "$tmp"
  echo "Generated power/${mode}_activity_generated.vcd"
done
