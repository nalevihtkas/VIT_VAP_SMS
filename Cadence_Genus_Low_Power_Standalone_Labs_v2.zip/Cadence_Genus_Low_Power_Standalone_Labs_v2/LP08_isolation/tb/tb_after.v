`timescale 1ns/1ps
module tb_top;reg clk=0,iso_n=1;reg[7:0]a=0,b=0;wire y;iso_after dut(.clk(clk),.iso_n(iso_n),.a(a),.b(b),.y(y));always #5 clk=~clk;integer i;initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top);for(i=0;i<100;i=i+1)begin @(negedge clk);a=$random;b=$random;iso_n=(i%4!=0);end #10 $finish;end endmodule
