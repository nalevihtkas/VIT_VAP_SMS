# LP08 — Isolation Cell

`before.v` passes a switched-domain result directly to the receiving register. `after.v` places a synthetic clamp-to-zero isolation cell (`ISO0_X1`) before the receiver. When `iso_n=0`, the receiving side is forced to 0.
