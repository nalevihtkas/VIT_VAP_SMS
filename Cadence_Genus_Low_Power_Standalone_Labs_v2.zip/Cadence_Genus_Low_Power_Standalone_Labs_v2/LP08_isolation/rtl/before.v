module iso_before(input clk,input iso_n,input [7:0] a,b,output reg y);
wire core = &(a ^ b);
always @(posedge clk) y <= core;
endmodule
