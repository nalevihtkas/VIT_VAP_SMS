module iso_after(input clk,input iso_n,input [7:0] a,b,output reg y);
wire core = &(a ^ b);
wire safe_core;
ISO0_X1 u_iso(.A(core),.ISO_N(iso_n),.Y(safe_core));
always @(posedge clk) y <= safe_core;
endmodule
