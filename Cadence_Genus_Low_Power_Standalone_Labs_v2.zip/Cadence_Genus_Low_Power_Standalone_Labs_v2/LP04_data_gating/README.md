# LP04 — Data Gating

`before.v` captures a changing 64-bit data bus every cycle. `after.v` feeds the old Q value back while disabled so D-side data activity is suppressed, but the clock continues toggling.
