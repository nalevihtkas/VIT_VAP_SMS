module dg_after(input clk,input rst_n,input enable,input [63:0] d,output reg [63:0] q);
wire [63:0] gated_d = enable ? d : q;
always @(posedge clk) begin
  if(!rst_n) q <= 64'd0;
  else q <= gated_d;
end
endmodule
