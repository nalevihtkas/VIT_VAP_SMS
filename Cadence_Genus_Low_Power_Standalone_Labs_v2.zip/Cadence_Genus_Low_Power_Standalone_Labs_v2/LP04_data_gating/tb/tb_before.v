`timescale 1ns/1ps
module tb_top;reg clk=0,rst_n=0,enable=0;reg[63:0]d=0;wire[63:0]q;dg_before dut(.clk(clk),.rst_n(rst_n),.enable(enable),.d(d),.q(q));always #5 clk=~clk;integer i;initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top);#20 rst_n=1;for(i=0;i<100;i=i+1)begin @(negedge clk);d={$random,$random};enable=(i%5==0);end #20 $finish;end endmodule
