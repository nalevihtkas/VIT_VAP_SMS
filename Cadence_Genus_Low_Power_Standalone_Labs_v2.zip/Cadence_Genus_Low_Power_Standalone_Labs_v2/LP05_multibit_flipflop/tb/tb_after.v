`timescale 1ns/1ps
module tb_top;reg clk=0;reg[3:0]d=0;wire[3:0]q;mbff_after dut(.clk(clk),.d(d),.q(q));always #5 clk=~clk;initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top);repeat(100)begin @(negedge clk);d=$random;end #10 $finish;end endmodule
