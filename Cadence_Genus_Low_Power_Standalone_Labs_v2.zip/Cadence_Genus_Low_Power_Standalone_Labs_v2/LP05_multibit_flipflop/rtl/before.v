module mbff_before(input clk,input [3:0] d,output [3:0] q);
DFF_X1 u0(.CLK(clk),.D(d[0]),.Q(q[0]));
DFF_X1 u1(.CLK(clk),.D(d[1]),.Q(q[1]));
DFF_X1 u2(.CLK(clk),.D(d[2]),.Q(q[2]));
DFF_X1 u3(.CLK(clk),.D(d[3]),.Q(q[3]));
endmodule
