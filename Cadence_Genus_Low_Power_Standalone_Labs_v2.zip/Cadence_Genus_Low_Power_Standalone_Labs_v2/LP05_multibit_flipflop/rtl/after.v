module mbff_after(input clk,input [3:0] d,output [3:0] q);
DFF4_X1 u_mbff(.CLK(clk),.D0(d[0]),.D1(d[1]),.D2(d[2]),.D3(d[3]),.Q0(q[0]),.Q1(q[1]),.Q2(q[2]),.Q3(q[3]));
endmodule
