set SCRIPT_DIR [file normalize [file dirname [info script]]]
set LAB_DIR    [file normalize "$SCRIPT_DIR/.."]
set COMMON     [file normalize "$LAB_DIR/../common"]
set RPT        "$LAB_DIR/reports"
set NET        "$LAB_DIR/netlist"
file mkdir $RPT
file mkdir $NET
set_db init_hdl_search_path "$LAB_DIR/rtl"
set_db init_lib_search_path "$COMMON/lib"
read_libs "$COMMON/lib/teaching_base.lib"

read_hdl "$LAB_DIR/rtl/after.v"
elaborate mbff_after
check_design -unresolved
read_sdc "$LAB_DIR/sdc/top.sdc"

syn_generic
syn_map
syn_opt

set VCD_FILE "$LAB_DIR/power/activity.vcd"
if {![file exists $VCD_FILE]} { error "Missing VCD file: $VCD_FILE" }
if {[catch {read_vcd $VCD_FILE -scope tb_top/dut} vcd_msg]} {
  error "VCD annotation failed for $VCD_FILE: $vcd_msg"
} else {
  puts "VCD annotation successful: $VCD_FILE"
}
report timing > "$RPT/after_timing.rpt"
report area   > "$RPT/after_area.rpt"
report gates  > "$RPT/after_gates.rpt"
report power  > "$RPT/after_power.rpt"
report qor    > "$RPT/after_qor.rpt"
write_hdl     > "$NET/after_mapped.v"
write_sdc     > "$NET/after_mapped.sdc"
puts "DONE: after"
exit
