# LP05 — Multi-Bit Flip-Flop Mapping

A technology-dependent structural teaching lab. `before.v` instantiates four single-bit `DFF_X1` cells. `after.v` instantiates one `DFF4_X1` teaching cell. The Liberty model gives the MBFF a smaller aggregate clock capacitance and area than four individual DFFs.

With a real PDK, prefer Genus/physical-design MBFF mapping rather than hand-instantiating a synthetic cell.
