set SCRIPT_DIR [file normalize [file dirname [info script]]]
set LAB_DIR    [file normalize "$SCRIPT_DIR/.."]
set COMMON     [file normalize "$LAB_DIR/../common"]
set RPT        "$LAB_DIR/reports"
set NET        "$LAB_DIR/netlist"
file mkdir $RPT
file mkdir $NET
set_db init_hdl_search_path "$LAB_DIR/rtl"
set_db init_lib_search_path "$COMMON/lib"
read_libs "$COMMON/lib/teaching_base.lib"

read_hdl "$LAB_DIR/rtl/after.v"
elaborate pg_after
read_sdc "$LAB_DIR/sdc/top.sdc"
if {[llength [info commands read_power_intent]] > 0} {
  if {[catch {read_power_intent -1801 "$LAB_DIR/intent/power_gating.upf"} msg]} {
    puts "UPF load syntax/license differs in this Genus release: $msg"
  } else {
    if {[llength [info commands apply_power_intent]] > 0} { catch {apply_power_intent} apmsg; puts "apply_power_intent: $apmsg" }
  }
} else {
  puts "read_power_intent command not available; continuing core synthesis."
}
syn_generic
syn_map
syn_opt
report power > "$RPT/upf_attempt_power.rpt"
write_hdl > "$NET/upf_attempt_mapped.v"
exit
