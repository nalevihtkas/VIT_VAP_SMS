`timescale 1ns/1ps
module tb_top;reg clk=0,rst_n=0,sleep=0;reg[7:0]a=0,b=0;wire[15:0]y;pg_after dut(.clk(clk),.rst_n(rst_n),.sleep(sleep),.a(a),.b(b),.y(y));always #5 clk=~clk;integer i;initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top);#20 rst_n=1;for(i=0;i<100;i=i+1)begin @(negedge clk);a=$random;b=$random;sleep=(i%4!=0);end #10 $finish;end endmodule
