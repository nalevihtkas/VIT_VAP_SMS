# LP07 — Power Gating

The core self-contained synthesis comparison uses a teaching `POWER_SWITCH_X1` status model in the after design. This demonstrates the control/structural overhead but does not claim transistor-level VDD disconnection. `intent/power_gating.upf` shows the IEEE 1801 intent that should be adapted to a real low-power library.
