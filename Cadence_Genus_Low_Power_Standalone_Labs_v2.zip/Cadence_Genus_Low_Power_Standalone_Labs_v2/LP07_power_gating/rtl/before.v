module pg_core(input [7:0] a,b, output [15:0] y);
assign y=a*b;
endmodule
module pg_before(input clk,input rst_n,input sleep,input [7:0] a,b,output reg [15:0] y);
wire [15:0] core_y; pg_core u_core(.a(a),.b(b),.y(core_y));
always @(posedge clk) begin if(!rst_n) y<=16'd0; else y<=core_y; end
endmodule
