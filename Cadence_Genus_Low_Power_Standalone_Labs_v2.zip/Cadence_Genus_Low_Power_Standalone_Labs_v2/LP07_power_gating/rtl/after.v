module pg_core(input [7:0] a,b, output [15:0] y);
assign y=a*b;
endmodule
module pg_after(input clk,input rst_n,input sleep,input [7:0] a,b,output reg [15:0] y);
wire pwr_ok; wire [15:0] core_y;
pg_core u_core(.a(a),.b(b),.y(core_y));
POWER_SWITCH_X1 u_ps(.SLEEP(sleep),.PWR_OK(pwr_ok));
always @(posedge clk) begin if(!rst_n) y<=16'd0; else if(pwr_ok) y<=core_y; else y<=16'd0; end
endmodule
