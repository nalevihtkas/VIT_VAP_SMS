# LP03 — Operand Isolation

Inputs change every cycle but `valid` is asserted only periodically. `before.v` allows the multiplier to toggle continuously. `after.v` clamps both operands to zero while invalid. Compare dynamic power and area/timing.
