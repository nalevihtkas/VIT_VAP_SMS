`timescale 1ns/1ps
module tb_top; reg clk=0,rst_n=0,valid=0;reg[15:0]a=0,b=0;wire[31:0]y;oi_before dut(.clk(clk),.rst_n(rst_n),.valid(valid),.a(a),.b(b),.y(y));always #5 clk=~clk;integer i;initial begin $dumpfile("activity.vcd");$dumpvars(0,tb_top);#20 rst_n=1;for(i=0;i<100;i=i+1)begin @(negedge clk);a=$random;b=$random;valid=(i%4==0);end #20 $finish;end endmodule
