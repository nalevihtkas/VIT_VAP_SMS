module oi_before(input clk,input rst_n,input valid,input [15:0] a,b,output reg [31:0] y);
wire [31:0] p = a*b;
always @(posedge clk) begin
  if(!rst_n) y <= 32'd0;
  else y <= valid ? p : 32'd0;
end
endmodule
