module oi_after(input clk,input rst_n,input valid,input [15:0] a,b,output reg [31:0] y);
wire [15:0] ia = valid ? a : 16'd0;
wire [15:0] ib = valid ? b : 16'd0;
wire [31:0] p = ia*ib;
always @(posedge clk) begin
  if(!rst_n) y <= 32'd0;
  else y <= valid ? p : 32'd0;
end
endmodule
