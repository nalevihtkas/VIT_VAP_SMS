#!/bin/sh
set -e

# Run from scripts folder: cd scripts
mkdir -p ../vcd

for CASE in clk_low clk_high data_low data_high
do
  echo "=== Icarus Verilog simulation: ${CASE} ==="
  rm -f ${CASE}.vcd sim_${CASE}.out
  iverilog -g2012 -o sim_${CASE}.out ../RTL/activity_power_top.v ../TB/tb_${CASE}.v
  vvp sim_${CASE}.out
  mv ${CASE}.vcd ../vcd/${CASE}.vcd
done

echo "All VCD files generated in ../vcd/"
