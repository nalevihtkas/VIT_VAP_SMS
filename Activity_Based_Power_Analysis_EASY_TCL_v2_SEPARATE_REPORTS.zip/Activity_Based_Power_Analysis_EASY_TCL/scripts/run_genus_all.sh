#!/bin/sh
set -e

# Run this script from the scripts folder: cd scripts
mkdir -p ../reports/clk_low ../reports/clk_high ../reports/data_low ../reports/data_high

for CASE in clk_low clk_high data_low data_high
do
  echo "=== Genus power analysis: ${CASE} ==="
  genus -f power_${CASE}.tcl
done

echo "All reports are available in separate folders under ../reports/"
echo "  ../reports/clk_low/"
echo "  ../reports/clk_high/"
echo "  ../reports/data_low/"
echo "  ../reports/data_high/"
