#!/bin/sh
set -e

# Run from scripts folder: cd scripts
MISSING=0
for F in clk_low.vcd clk_high.vcd data_low.vcd data_high.vcd
do
  if [ ! -s "../vcd/$F" ]; then
    echo "MISSING or EMPTY: ../vcd/$F"
    MISSING=1
  else
    echo "OK: ../vcd/$F"
  fi
done

if [ "$MISSING" -ne 0 ]; then
  echo "VCD check FAILED"
  exit 1
fi

echo "VCD check PASSED"
