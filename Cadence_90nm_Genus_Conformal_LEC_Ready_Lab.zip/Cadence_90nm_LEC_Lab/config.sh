#!/usr/bin/env bash
# EDIT THIS LINE ONLY to use your 90nm .lib; no other paths required.
export LIBERTY="/EDIT/TO/YOUR/90nm_standard_cells.lib"
# Executable names may be changed here if your site uses wrappers.
export GENUS_BIN="${GENUS_BIN:-genus}"
export LEC_BIN="${LEC_BIN:-lec}"
