#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
source ./config.sh
if [[ ! -f "$LIBERTY" ]]; then
  echo "ERROR: Edit LIBERTY in config.sh to your installed 90nm .lib" >&2
  exit 2
fi
command -v "$GENUS_BIN" >/dev/null || { echo "ERROR: Genus not found: $GENUS_BIN" >&2; exit 2; }
command -v "$LEC_BIN" >/dev/null || { echo "ERROR: Conformal not found: $LEC_BIN" >&2; exit 2; }
mkdir -p outputs reports logs
case "${1:-all}" in
  synth|all)
    export RTL_FILE=rtl/design.v OUT_FILE=outputs/design_synth.v REPORT_STEM=good
    "$GENUS_BIN" -files scripts/genus.tcl -log logs/genus_good.log
    test -s "$OUT_FILE" || { echo 'No synthesized netlist'; exit 1; }
    export RTL_FILE=rtl/design_faulty.v OUT_FILE=outputs/design_faulty_synth.v REPORT_STEM=faulty
    "$GENUS_BIN" -files scripts/genus.tcl -log logs/genus_faulty.log
    test -s "$OUT_FILE" || { echo 'No faulty synthesized netlist'; exit 1; }
    [[ "${1:-all}" == synth ]] && exit 0
    ;;
  pass|fail) ;;
  *) echo 'Usage: ./run.sh [all|synth|pass|fail]'; exit 2 ;;
esac
if [[ "${1:-all}" == all || "${1:-all}" == pass ]]; then
  test -s outputs/design_synth.v || { echo 'Run ./run.sh synth first'; exit 2; }
  "$LEC_BIN" -nogui -dofile scripts/lec_pass.do -logfile logs/lec_pass.log
fi
if [[ "${1:-all}" == all || "${1:-all}" == fail ]]; then
  test -s outputs/design_faulty_synth.v || { echo 'Run ./run.sh synth first'; exit 2; }
  "$LEC_BIN" -nogui -dofile scripts/lec_fail.do -logfile logs/lec_fail.log
fi
echo 'Inspect reports/ and logs/; tool exit status alone does not establish LEC PASS/FAIL.'
