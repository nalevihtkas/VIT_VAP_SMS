# Conformal RTL (golden) vs Genus mapped netlist (revised)
read library -liberty $env(LIBERTY) -both
read design rtl/design.v -verilog -golden
read design outputs/design_synth.v -verilog -revised
set root module design -golden
set root module design -revised
set system mode lec
add compared points -all
compare
report verification -verbose > reports/lec_pass.rpt
report compare data -class nonequivalent > reports/lec_pass_noneq.rpt
exit
