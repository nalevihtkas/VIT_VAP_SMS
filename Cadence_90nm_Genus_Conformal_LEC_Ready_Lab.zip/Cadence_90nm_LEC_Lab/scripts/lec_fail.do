# Conformal RTL (golden) vs deliberately wrong, Genus mapped netlist (revised)
read library -liberty $env(LIBERTY) -both
read design rtl/design.v -verilog -golden
read design outputs/design_faulty_synth.v -verilog -revised
set root module design -golden
set root module design -revised
set system mode lec
add compared points -all
compare
report verification -verbose > reports/lec_fail.rpt
report compare data -class nonequivalent > reports/lec_fail_noneq.rpt
exit
