# Invoked from the package root by run.sh.
# Environment variables RTL_FILE, OUT_FILE and LIBERTY are set by run.sh.
set_db library [list $::env(LIBERTY)]
read_hdl -language verilog $::env(RTL_FILE)
elaborate design
check_design -unresolved
read_sdc constraints.sdc
syn_generic
syn_map
syn_opt
write_hdl > $::env(OUT_FILE)
report_area > "reports/$::env(REPORT_STEM)_area.rpt"
report_timing > "reports/$::env(REPORT_STEM)_timing.rpt"
write_sdc > "outputs/$::env(REPORT_STEM).sdc"
puts "GENUS FINISHED: $::env(OUT_FILE)"
