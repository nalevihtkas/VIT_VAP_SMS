# Cadence 90nm Genus → Conformal LEC lab

## Setup
- Licensed Cadence Genus and Conformal must be on PATH.
- Edit **only** `LIBERTY` in `config.sh` to point to a 90nm standard-cell `.lib`.
- The library must include all mapped cells; if your PDK uses separate sequential and combinational Liberty files, adjust `set_db library` and `read library` to load all of them.
- Work on Linux/bash in the extracted directory.

## Commands
```bash
chmod +x run.sh
./run.sh synth  # synthesize both golden and deliberately faulty RTL to 90nm gates
./run.sh pass   # golden RTL vs correctly synthesized netlist
./run.sh fail   # golden RTL vs synthesized faulty netlist
# or: ./run.sh all
```

## Expected
- PASS: all compare points equivalent.
- FAIL: at least one output/state compare point non-equivalent because XOR became OR.
- Reports in `reports/`; tool transcripts in `logs/`; mapped Verilog in `outputs/`.

## Important
- This lab does NOT ship a 90nm PDK or Liberty file.
- It has NOT been executed with Cadence tools in this environment; exact `read library`, `report` and executable flags can vary by Cadence release. Check the first error in the logs if your site release differs.
- The FAIL case is **not** a synthesis error: the faulty RTL is synthesized separately to create an actual technology-mapped faulty netlist, which is then compared against the correct RTL.
- An `exit 0` from the LEC program is not proof of equivalence; read the Conformal verification report and ensure the compare-point count and classifications are complete.
- This simple lab assumes the technology library provides appropriate flip-flops and reset behavior for the RTL.
