module design (
 input wire clk, rst_n, sel,
 input wire [7:0] a,b,c,
 output reg [8:0] y
);
wire [8:0] aa = {1'b0,a};
wire [8:0] bb = {1'b0,b};
wire [8:0] cc = {1'b0,c};
wire [8:0] value = sel ? ((aa+bb)^cc) : ((aa-bb)+cc);
always @(posedge clk or negedge rst_n)
  if (!rst_n) y <= 9'd0;
  else y <= value;
endmodule
