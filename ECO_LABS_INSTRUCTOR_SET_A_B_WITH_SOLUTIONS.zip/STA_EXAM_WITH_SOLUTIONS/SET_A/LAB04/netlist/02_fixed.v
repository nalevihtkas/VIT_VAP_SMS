// ECO_LAB 04 - ANSWER netlist: 8 x X1 cells resized to X2 (same instances, same nets)
module eco_lab04(input clk,input din,output qout);
 wire n0,n1,n2,n3,n4,n5,n6,n7,n8;
 DFFNEG_X1 U_LAUNCH(.CLK(clk),.D(din),.Q(n0));
 NOR2_X2 g0(.A(n0),.B(1'b0),.Y(n1));
 NOR2_X2 g1(.A(n1),.B(1'b0),.Y(n2));
 NOR2_X2 g2(.A(n2),.B(1'b0),.Y(n3));
 NOR2_X2 g3(.A(n3),.B(1'b0),.Y(n4));
 NOR2_X2 g4(.A(n4),.B(1'b0),.Y(n5));
 NOR2_X2 g5(.A(n5),.B(1'b0),.Y(n6));
 NOR2_X2 g6(.A(n6),.B(1'b0),.Y(n7));
 NOR2_X2 g7(.A(n7),.B(1'b0),.Y(n8));
 DFFPOS_X1 U_CAPTURE(.CLK(clk),.D(n8),.Q(qout));
endmodule
