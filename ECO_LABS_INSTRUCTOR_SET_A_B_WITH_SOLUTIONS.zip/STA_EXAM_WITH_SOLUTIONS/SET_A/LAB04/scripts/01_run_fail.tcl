# ECO_LAB 04 - QUESTION (FAIL)
# Run from this experiment directory: tempus -files scripts/01_run_fail.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 01_fail.v]
set SDC [file join $LAB_DIR sdc 01_fail.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab04
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 04 - QUESTION (FAIL): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "Path          : U_LAUNCH/CLK -> U_LAUNCH/Q -> 8 x NOR2_X1 -> U_CAPTURE/D"
puts "Flip-flops    : launch DFFNEG_X1 (falling edge), capture DFFPOS_X1 (rising edge)"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns  (2-input gates: side pin tied to non-controlling value)"
puts "Data path     : 8 x 0.60 = 4.80 ns"
puts "Arrival time  : CLK->Q + data = 0.20 + 4.80 = 5.00 ns"
puts ""
puts "--- SETUP CHECK (report_timing -late) ---"
puts "Launch edge   : 4.00 ns, capture edge: 8.00 ns -> phase shift 4.00 ns"
puts "Required time : 4.00 - 0.20 = 3.80 ns   (phase shift - setup)"
puts "Setup slack   : Required - Arrival = 3.80 - 5.00 = -1.20 ns  -> VIOLATED"
puts ""
puts "--- HOLD CHECK (report_timing -early) ---"
puts "Launch edge   : 4.00 ns, hold capture edge: 0.00 ns -> phase shift -4.00 ns"
puts "Required time : (-4.00) + 0.10 = -3.90 ns   (phase shift + hold)"
puts "Hold slack    : Arrival - Required = 5.00 - (-3.90) = +8.90 ns  -> MET"
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- SETUP (late) report -----"
report_timing -late -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
puts "\n----- HOLD (early) report -----"
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
exit
