# ECO_LAB 04 - ANSWER (FIXED)
# Run from this experiment directory: tempus -files scripts/02_run_fixed.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 02_fixed.v]
set SDC [file join $LAB_DIR sdc 02_fixed.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab04
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 04 - ANSWER (FIXED): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "Netlist change: 8 x X1 cells resized to X2 (same instances, same nets)"
puts "Clock / SDC   : UNCHANGED"
puts "Path          : U_LAUNCH/CLK -> U_LAUNCH/Q -> 8 x NOR2_X2 -> U_CAPTURE/D"
puts "Flip-flops    : launch DFFNEG_X1 (falling edge), capture DFFPOS_X1 (rising edge)"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns  (2-input gates: side pin tied to non-controlling value)"
puts "Data path     : 8 x 0.30 = 2.40 ns"
puts "Arrival time  : CLK->Q + data = 0.20 + 2.40 = 2.60 ns"
puts ""
puts "--- SETUP CHECK (report_timing -late) ---"
puts "Launch edge   : 4.00 ns, capture edge: 8.00 ns -> phase shift 4.00 ns"
puts "Required time : 4.00 - 0.20 = 3.80 ns   (phase shift - setup)"
puts "Setup slack   : Required - Arrival = 3.80 - 2.60 = +1.20 ns  -> MET"
puts ""
puts "--- HOLD CHECK (report_timing -early) ---"
puts "Launch edge   : 4.00 ns, hold capture edge: 0.00 ns -> phase shift -4.00 ns"
puts "Required time : (-4.00) + 0.10 = -3.90 ns   (phase shift + hold)"
puts "Hold slack    : Arrival - Required = 2.60 - (-3.90) = +6.50 ns  -> MET"
puts "Improvement   : setup slack -1.20 -> +1.20 ns (gain 2.40 ns)"
puts ""
puts "HOW IT IS FIXED"
puts "1. Why it fails: arrival 5.00 ns > required 3.80 ns, so data is 1.20 ns too LATE."
puts "   The time available is only the HALF-cycle window between opposite clock edges (4.00 ns phase shift - 0.20 setup)."
puts "   Clock, uncertainty and flip-flop edges are sign-off requirements, so the only legal"
puts "   knob is the data-path delay (the maximum path must get FASTER)."
puts "2. What was changed: every X1 cell on the path was swapped for its X2 version:"
puts "     8 x NOR2_X1 (0.60 ns) -> NOR2_X2 (0.30 ns): saves 8 x 0.30 = 2.40 ns"
puts "   X2 has the same logic function and the same pins (same footprint), so no net or"
puts "   logic changes - this is gate SIZING (ECO size_cell / ecoChangeCell in a real flow)."
puts "   The stronger X2 transistors charge the next stage faster, so each stage delay drops."
puts "3. Result: arrival 5.00 -> 2.60 ns; setup slack -1.20 -> +1.20 ns (gain 2.40 ns = total delay saved)."
puts "4. Cost / side effects: comb. area 12.0 -> 19.2 units; hold slack +8.90 -> +6.50 ns"
puts "   (a faster path always eats hold margin - it is still MET here, so the fix is complete)."
puts "   Changing the period or flop type would also 'pass' but changes the design spec - not allowed."
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- SETUP (late) report -----"
report_timing -late -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
puts "\n----- HOLD (early) report -----"
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
exit
