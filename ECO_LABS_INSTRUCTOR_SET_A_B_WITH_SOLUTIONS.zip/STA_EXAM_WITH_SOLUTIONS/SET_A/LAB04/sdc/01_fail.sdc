create_clock -name CLK -period 8 -waveform {0 4} [get_ports clk]
