# ECO_LAB 05 - QUESTION (FAIL)
# Run from this experiment directory: tempus -files scripts/01_run_fail.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 01_fail.v]
set SDC [file join $LAB_DIR sdc 01_fail.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab05
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 05 - QUESTION (FAIL): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "DATA path:"
puts "  Path          : U_DATA_L/CLK -> U_DATA_L/Q -> 6 x INV_X1 -> U_DATA_C/D"
puts "  Flip-flops    : launch DFFPOS_X1 (rising edge), capture DFFPOS_X1 (rising edge)"
puts "  Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns"
puts "  Data path     : 6 x 0.40 = 2.40 ns"
puts "  Arrival time  : CLK->Q + data = 0.20 + 2.40 = 2.60 ns"
puts "  "
puts "  --- SETUP CHECK (report_timing -late) ---"
puts "  Launch edge   : 0.00 ns, capture edge: 5.00 ns -> phase shift 5.00 ns"
puts "  Required time : 5.00 - 0.20 = 4.80 ns   (phase shift - setup)"
puts "  Setup slack   : Required - Arrival = 4.80 - 2.60 = +2.20 ns  -> MET"
puts "  "
puts "  --- HOLD CHECK (report_timing -early) ---"
puts "  Launch edge   : 0.00 ns, hold capture edge: 0.00 ns -> phase shift 0.00 ns"
puts "  Required time : 0.00 + 0.10 = 0.10 ns   (phase shift + hold)"
puts "  Hold slack    : Arrival - Required = 2.60 - 0.10 = +2.50 ns  -> MET"
puts ""
puts "CFG path:"
puts "  Path          : U_CFG_L/CLK -> U_CFG_L/Q -> 12 x NAND2_X1 -> U_CFG_C/D"
puts "  Flip-flops    : launch DFFPOS_X1 (rising edge), capture DFFPOS_X1 (rising edge)"
puts "  Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns  (2-input gates: side pin tied to non-controlling value)"
puts "  Data path     : 12 x 0.45 = 5.40 ns"
puts "  Arrival time  : CLK->Q + data = 0.20 + 5.40 = 5.60 ns"
puts "  "
puts "  --- SETUP CHECK (report_timing -late) ---"
puts "  Launch edge   : 0.00 ns, capture edge: 5.00 ns -> phase shift 5.00 ns"
puts "  Required time : 5.00 - 0.20 = 4.80 ns   (phase shift - setup)"
puts "  Setup slack   : Required - Arrival = 4.80 - 5.60 = -0.80 ns  -> VIOLATED"
puts "  "
puts "  --- HOLD CHECK (report_timing -early) ---"
puts "  Launch edge   : 0.00 ns, hold capture edge: 0.00 ns -> phase shift 0.00 ns"
puts "  Required time : 0.00 + 0.10 = 0.10 ns   (phase shift + hold)"
puts "  Hold slack    : Arrival - Required = 5.60 - 0.10 = +5.50 ns  -> MET"
puts ""
puts "Expected      : DATA passes, CFG fails setup while timed as an ordinary path."
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- DATA SETUP (late) -----"
report_timing -late -path_type full_clock -from [get_pins U_DATA_L/CLK] -to [get_pins U_DATA_C/D] -max_paths 1
puts "\n----- DATA HOLD (early) -----"
report_timing -early -path_type full_clock -from [get_pins U_DATA_L/CLK] -to [get_pins U_DATA_C/D] -max_paths 1
puts "\n----- CFG SETUP (late) -----"
report_timing -late -path_type full_clock -from [get_pins U_CFG_L/CLK] -to [get_pins U_CFG_C/D] -max_paths 1
puts "\n----- CFG HOLD (early) -----"
report_timing -early -path_type full_clock -from [get_pins U_CFG_L/CLK] -to [get_pins U_CFG_C/D] -max_paths 1
exit
