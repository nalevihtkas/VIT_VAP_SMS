create_clock -name CLK -period 5 [get_ports clk]
# CFG register is quasi-static configuration: functionally justified exception
set_false_path -from [get_cells U_CFG_L] -to [get_pins U_CFG_C/D]
