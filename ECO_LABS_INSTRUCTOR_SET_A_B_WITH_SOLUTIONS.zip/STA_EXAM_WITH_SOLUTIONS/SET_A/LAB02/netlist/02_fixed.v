// ECO_LAB 02 - ANSWER netlist: Inserted 2 x DLY_X1 before U_CAPTURE/D
module eco_lab02(input clk,input din,output qout);
 wire n0,n1,n2,n3,n4;
 DFFPOS_X1 U_LAUNCH(.CLK(clk),.D(din),.Q(n0));
 INV_X1 g0(.A(n0),.Y(n1));
 INV_X1 g1(.A(n1),.Y(n2));
 DLY_X1 HOLD_DLY0(.A(n2),.Y(n3));
 DLY_X1 HOLD_DLY1(.A(n3),.Y(n4));
 DFFPOS_X1 U_CAPTURE(.CLK(clk),.D(n4),.Q(qout));
endmodule
