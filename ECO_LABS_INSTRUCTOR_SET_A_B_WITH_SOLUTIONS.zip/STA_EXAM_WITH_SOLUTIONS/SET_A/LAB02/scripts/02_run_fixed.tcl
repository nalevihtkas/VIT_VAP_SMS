# ECO_LAB 02 - ANSWER (FIXED)
# Run from this experiment directory: tempus -files scripts/02_run_fixed.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 02_fixed.v]
set SDC [file join $LAB_DIR sdc 02_fixed.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab02
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 02 - ANSWER (FIXED): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "Netlist change: Inserted 2 x DLY_X1 before U_CAPTURE/D"
puts "Clock / SDC   : UNCHANGED"
puts "Path          : U_LAUNCH/CLK -> U_LAUNCH/Q -> 2 x INV_X1 + 2 x DLY_X1 -> U_CAPTURE/D"
puts "Flip-flops    : launch DFFPOS_X1 (rising edge), capture DFFPOS_X1 (rising edge)"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns"
puts "Data path     : 2 x 0.40 + 2 x 1.00 = 2.80 ns"
puts "Arrival time  : CLK->Q + data = 0.20 + 2.80 = 3.00 ns"
puts ""
puts "--- SETUP CHECK (report_timing -late) ---"
puts "Launch edge   : 0.00 ns, capture edge: 10.00 ns -> phase shift 10.00 ns"
puts "Required time : 10.00 - 0.20 = 9.80 ns   (phase shift - setup)"
puts "Setup slack   : Required - Arrival = 9.80 - 3.00 = +6.80 ns  -> MET"
puts ""
puts "--- HOLD CHECK (report_timing -early) ---"
puts "SDC           : set_min_delay 2.50 replaces the 0.00 ns hold relationship"
puts "Required time : 2.50 + 0.10 = 2.60 ns   (min delay + library hold)"
puts "Hold slack    : Arrival - Required = 3.00 - 2.60 = +0.40 ns  -> MET"
puts "Check         : with only ONE DLY_X1 hold slack = -0.60 ns -> VIOLATED"
puts "Improvement   : hold slack -1.60 -> +0.40 ns (gain 2.00 ns)"
puts ""
puts "HOW IT IS FIXED"
puts "1. Why it fails: arrival 1.00 ns < required 2.60 ns (set_min_delay 2.50 + library hold 0.10), so data is 1.60 ns too EARLY."
puts "   New data would race through and corrupt the value being captured on the same edge."
puts "   The constraint is a requirement, so the minimum path must get SLOWER."
puts "2. What was changed: 2 x DLY_X1 (1.00 ns each) inserted in series just before U_CAPTURE/D"
puts "   -> adds 2 x 1.00 = 2.00 ns >= 1.60 ns needed."
puts "   1 cell(s) would add only 1.00 ns < 1.60 ns -> still fails, so 2 are required."
puts "   Inserting at the capture end keeps the extra delay on this path only (in a real flow:"
puts "   ecoAddRepeater / hold-fix buffer insertion). No existing cell is resized or removed."
puts "3. Result: arrival 1.00 -> 3.00 ns; hold slack -1.60 -> +0.40 ns."
puts "4. Always re-check setup after a hold fix: setup slack +8.80 -> +6.80 ns (still MET)."
puts "   Area cost: +2.0 units."
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- HOLD (early) report -----"
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
puts "\n----- SETUP (late) report -----"
report_timing -late -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
exit
