# ECO_LAB 02 - QUESTION (FAIL)
# Run from this experiment directory: tempus -files scripts/01_run_fail.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 01_fail.v]
set SDC [file join $LAB_DIR sdc 01_fail.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab02
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 02 - QUESTION (FAIL): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "Path          : U_LAUNCH/CLK -> U_LAUNCH/Q -> 2 x INV_X1 -> U_CAPTURE/D"
puts "Flip-flops    : launch DFFPOS_X1 (rising edge), capture DFFPOS_X1 (rising edge)"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns"
puts "Data path     : 2 x 0.40 = 0.80 ns"
puts "Arrival time  : CLK->Q + data = 0.20 + 0.80 = 1.00 ns"
puts ""
puts "--- SETUP CHECK (report_timing -late) ---"
puts "Launch edge   : 0.00 ns, capture edge: 10.00 ns -> phase shift 10.00 ns"
puts "Required time : 10.00 - 0.20 = 9.80 ns   (phase shift - setup)"
puts "Setup slack   : Required - Arrival = 9.80 - 1.00 = +8.80 ns  -> MET"
puts ""
puts "--- HOLD CHECK (report_timing -early) ---"
puts "SDC           : set_min_delay 2.50 replaces the 0.00 ns hold relationship"
puts "Required time : 2.50 + 0.10 = 2.60 ns   (min delay + library hold)"
puts "Hold slack    : Arrival - Required = 1.00 - 2.60 = -1.60 ns  -> VIOLATED"
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- HOLD (early) report -----"
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
puts "\n----- SETUP (late) report -----"
report_timing -late -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
exit
