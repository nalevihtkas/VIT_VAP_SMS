# ECO_LAB 03 - QUESTION (FAIL)
# Run from this experiment directory: tempus -files scripts/01_run_fail.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 01_fail.v]
set SDC [file join $LAB_DIR sdc 01_fail.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab03
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 03 - QUESTION (FAIL): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "Path          : U_LAUNCH/CLK -> U_LAUNCH/Q -> 6 x OR2_X1 -> U_CAPTURE/D"
puts "Flip-flops    : launch DFFPOS_X1 (rising edge), capture DFFPOS_X1 (rising edge)"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns  (2-input gates: side pin tied to non-controlling value)"
puts "Data path     : 6 x 0.65 = 3.90 ns"
puts "Arrival time  : CLK->Q + data = 0.20 + 3.90 = 4.10 ns"
puts ""
puts "--- SETUP CHECK (report_timing -late) ---"
puts "Launch edge   : 0.00 ns, capture edge: 4.40 ns -> phase shift 4.40 ns"
puts "Required time : 4.40 - 0.20 - 0.40 = 3.80 ns   (phase shift - setup - setup uncertainty)"
puts "Setup slack   : Required - Arrival = 3.80 - 4.10 = -0.30 ns  -> VIOLATED"
puts ""
puts "--- HOLD CHECK (report_timing -early) ---"
puts "Launch edge   : 0.00 ns, hold capture edge: 0.00 ns -> phase shift 0.00 ns"
puts "Required time : 0.00 + 0.10 = 0.10 ns   (phase shift + hold)"
puts "Hold slack    : Arrival - Required = 4.10 - 0.10 = +4.00 ns  -> MET"
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- SETUP (late) report -----"
report_timing -late -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
puts "\n----- HOLD (early) report -----"
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
exit
