# ECO_LAB 01 - QUESTION (FAIL)
# Run from this experiment directory: tempus -files scripts/01_run_fail.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 01_fail.v]
set SDC [file join $LAB_DIR sdc 01_fail.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab01
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 01 - QUESTION (FAIL): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "Path          : U_LAUNCH/CLK -> U_LAUNCH/Q -> 8 x INV_X1 -> U_CAPTURE/D"
puts "Flip-flops    : launch DFFPOS_X1 (rising edge), capture DFFPOS_X1 (rising edge)"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns"
puts "Data path     : 8 x 0.40 = 3.20 ns"
puts "Arrival time  : CLK->Q + data = 0.20 + 3.20 = 3.40 ns"
puts ""
puts "--- SETUP CHECK (report_timing -late) ---"
puts "Launch edge   : 0.00 ns, capture edge: 3.40 ns -> phase shift 3.40 ns"
puts "Required time : 3.40 - 0.20 = 3.20 ns   (phase shift - setup)"
puts "Setup slack   : Required - Arrival = 3.20 - 3.40 = -0.20 ns  -> VIOLATED"
puts ""
puts "--- HOLD CHECK (report_timing -early) ---"
puts "Launch edge   : 0.00 ns, hold capture edge: 0.00 ns -> phase shift 0.00 ns"
puts "Required time : 0.00 + 0.10 = 0.10 ns   (phase shift + hold)"
puts "Hold slack    : Arrival - Required = 3.40 - 0.10 = +3.30 ns  -> MET"
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- SETUP (late) report -----"
report_timing -late -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
puts "\n----- HOLD (early) report -----"
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
exit
