# ECO_LAB 03 - ANSWER (FIXED)
# Run from this experiment directory: tempus -files scripts/02_run_fixed.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 02_fixed.v]
set SDC [file join $LAB_DIR sdc 02_fixed.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab03
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 03 - ANSWER (FIXED): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "Netlist change: 4 x X1 cells resized to X2 (same instances, same nets)"
puts "Clock / SDC   : UNCHANGED"
puts "Path          : U_LAUNCH/CLK -> U_LAUNCH/Q -> 4 x XOR2_X2 -> U_CAPTURE/D"
puts "Flip-flops    : launch DFFPOS_X1 (rising edge), capture DFFPOS_X1 (rising edge)"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns  (2-input gates: side pin tied to non-controlling value)"
puts "Data path     : 4 x 0.40 = 1.60 ns"
puts "Arrival time  : CLK->Q + data = 0.20 + 1.60 = 1.80 ns"
puts ""
puts "--- SETUP CHECK (report_timing -late) ---"
puts "Launch edge   : 0.00 ns, capture edge: 3.40 ns -> phase shift 3.40 ns"
puts "Required time : 3.40 - 0.20 - 0.30 = 2.90 ns   (phase shift - setup - setup uncertainty)"
puts "Setup slack   : Required - Arrival = 2.90 - 1.80 = +1.10 ns  -> MET"
puts ""
puts "--- HOLD CHECK (report_timing -early) ---"
puts "Launch edge   : 0.00 ns, hold capture edge: 0.00 ns -> phase shift 0.00 ns"
puts "Required time : 0.00 + 0.10 = 0.10 ns   (phase shift + hold)"
puts "Hold slack    : Arrival - Required = 1.80 - 0.10 = +1.70 ns  -> MET"
puts "Improvement   : setup slack -0.10 -> +1.10 ns (gain 1.20 ns)"
puts ""
puts "HOW IT IS FIXED"
puts "1. Why it fails: arrival 3.00 ns > required 2.90 ns, so data is 0.10 ns too LATE."
puts "   The time available is the clock period minus the setup uncertainty (3.40 ns phase shift - 0.30 uncertainty - 0.20 setup)."
puts "   Clock, uncertainty and flip-flop edges are sign-off requirements, so the only legal"
puts "   knob is the data-path delay (the maximum path must get FASTER)."
puts "2. What was changed: every X1 cell on the path was swapped for its X2 version:"
puts "     4 x XOR2_X1 (0.70 ns) -> XOR2_X2 (0.40 ns): saves 4 x 0.30 = 1.20 ns"
puts "   X2 has the same logic function and the same pins (same footprint), so no net or"
puts "   logic changes - this is gate SIZING (ECO size_cell / ecoChangeCell in a real flow)."
puts "   The stronger X2 transistors charge the next stage faster, so each stage delay drops."
puts "3. Result: arrival 3.00 -> 1.80 ns; setup slack -0.10 -> +1.10 ns (gain 1.20 ns = total delay saved)."
puts "4. Cost / side effects: comb. area 12.0 -> 18.0 units; hold slack +2.90 -> +1.70 ns"
puts "   (a faster path always eats hold margin - it is still MET here, so the fix is complete)."
puts "   The uncertainty was NOT removed: deleting it would only hide the problem on silicon."
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- SETUP (late) report -----"
report_timing -late -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
puts "\n----- HOLD (early) report -----"
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
exit
