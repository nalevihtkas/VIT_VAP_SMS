// ECO_LAB 02 - ANSWER netlist: Inserted 2 x BUF_X1 before U_CAPTURE/D
module eco_lab02(input clk,input din,output qout);
 wire n0,n1,n2,n3,n4;
 DFFPOS_X1 U_LAUNCH(.CLK(clk),.D(din),.Q(n0));
 NAND2_X1 g0(.A(n0),.B(1'b1),.Y(n1));
 NOR2_X1 g1(.A(n1),.B(1'b0),.Y(n2));
 BUF_X1 HOLD_BUF0(.A(n2),.Y(n3));
 BUF_X1 HOLD_BUF1(.A(n3),.Y(n4));
 DFFPOS_X1 U_CAPTURE(.CLK(clk),.D(n4),.Q(qout));
endmodule
