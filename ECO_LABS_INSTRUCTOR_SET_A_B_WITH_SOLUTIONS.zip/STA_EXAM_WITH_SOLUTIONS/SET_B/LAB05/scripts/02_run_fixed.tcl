# ECO_LAB 05 - ANSWER (FIXED)
# Run from this experiment directory: tempus -files scripts/02_run_fixed.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 02_fixed.v]
set SDC [file join $LAB_DIR sdc 02_fixed.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab05
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 05 - ANSWER (FIXED): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "SDC change    : set_false_path -from \[get_cells U_CFG_L\] -to \[get_pins U_CFG_C/D\]"
puts "Netlist       : UNCHANGED"
puts ""
puts "DATA path:"
puts "  Path          : U_DATA_L/CLK -> U_DATA_L/Q -> 4 x NOR2_X1 -> U_DATA_C/D"
puts "  Flip-flops    : launch DFFPOS_X1 (rising edge), capture DFFPOS_X1 (rising edge)"
puts "  Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns  (2-input gates: side pin tied to non-controlling value)"
puts "  Data path     : 4 x 0.60 = 2.40 ns"
puts "  Arrival time  : CLK->Q + data = 0.20 + 2.40 = 2.60 ns"
puts "  "
puts "  --- SETUP CHECK (report_timing -late) ---"
puts "  Launch edge   : 0.00 ns, capture edge: 5.00 ns -> phase shift 5.00 ns"
puts "  Required time : 5.00 - 0.20 = 4.80 ns   (phase shift - setup)"
puts "  Setup slack   : Required - Arrival = 4.80 - 2.60 = +2.20 ns  -> MET"
puts "  "
puts "  --- HOLD CHECK (report_timing -early) ---"
puts "  Launch edge   : 0.00 ns, hold capture edge: 0.00 ns -> phase shift 0.00 ns"
puts "  Required time : 0.00 + 0.10 = 0.10 ns   (phase shift + hold)"
puts "  Hold slack    : Arrival - Required = 2.60 - 0.10 = +2.50 ns  -> MET"
puts ""
puts "CFG path:"
puts "  CFG arrival is still 5.80 ns; if timed its setup slack would still be -1.00 ns."
puts "  It is now EXCLUDED from setup and hold analysis - it does NOT gain positive slack."
puts "Expected      : worst reports show only the DATA path; explicit CFG report finds no constrained path."
puts ""
puts "HOW IT IS FIXED"
puts "1. Why the CFG path 'fails': arrival 5.80 ns > required 4.80 ns (slack -1.00 ns) - but only because STA assumes it must settle in ONE cycle."
puts "   U_CFG_L is quasi-static: it changes only while the block is idle and is stable for many"
puts "   cycles before U_CFG_C uses it, so a single-cycle check does not describe real behaviour."
puts "2. What was changed: nothing in the netlist. One SDC line was added:"
puts "     set_false_path -from \[get_cells U_CFG_L\] -to \[get_pins U_CFG_C/D\]"
puts "   This removes the CFG path from BOTH setup and hold analysis."
puts "3. Result: CFG is no longer reported (it does NOT get positive slack - its arrival is still 5.80 ns)."
puts "   DATA stays fully timed: setup +2.20 ns, hold +2.50 ns."
puts "4. Why not size the CFG gates: it would cost area/power for a path that never needs it."
puts "   Why not false-path DATA too: DATA changes every cycle - that would hide a real bug."
puts "   Rule: a false path needs a FUNCTIONAL reason, never just 'it fails'."
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- WORST SETUP paths (late) -----"
report_timing -late -path_type full_clock -max_paths 5
puts "\n----- WORST HOLD paths (early) -----"
report_timing -early -path_type full_clock -max_paths 5
puts "\n----- CFG path after set_false_path (expect: no constrained path) -----"
report_timing -late -path_type full_clock -from [get_pins U_CFG_L/CLK] -to [get_pins U_CFG_C/D] -max_paths 1
exit
