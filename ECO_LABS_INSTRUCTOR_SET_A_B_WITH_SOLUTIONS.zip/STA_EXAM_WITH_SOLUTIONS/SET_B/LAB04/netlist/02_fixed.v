// ECO_LAB 04 - ANSWER netlist: 6 x X1 cells resized to X2 (same instances, same nets)
module eco_lab04(input clk,input din,output qout);
 wire n0,n1,n2,n3,n4,n5,n6;
 DFFNEG_X1 U_LAUNCH(.CLK(clk),.D(din),.Q(n0));
 XOR2_X2 g0(.A(n0),.B(1'b0),.Y(n1));
 XOR2_X2 g1(.A(n1),.B(1'b0),.Y(n2));
 XOR2_X2 g2(.A(n2),.B(1'b0),.Y(n3));
 XOR2_X2 g3(.A(n3),.B(1'b0),.Y(n4));
 XOR2_X2 g4(.A(n4),.B(1'b0),.Y(n5));
 XOR2_X2 g5(.A(n5),.B(1'b0),.Y(n6));
 DFFPOS_X1 U_CAPTURE(.CLK(clk),.D(n6),.Q(qout));
endmodule
