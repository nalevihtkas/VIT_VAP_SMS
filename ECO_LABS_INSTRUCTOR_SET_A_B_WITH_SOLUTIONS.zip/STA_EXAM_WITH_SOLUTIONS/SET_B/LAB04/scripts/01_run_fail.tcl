# ECO_LAB 04 - QUESTION (FAIL)
# Run from this experiment directory: tempus -files scripts/01_run_fail.tcl
set SCRIPT_DIR [file dirname [file normalize [info script]]]
set LAB_DIR [file normalize [file join $SCRIPT_DIR ..]]
set LIB [file join $LAB_DIR lib teaching_sta_physical.lib]
set NETLIST [file join $LAB_DIR netlist 01_fail.v]
set SDC [file join $LAB_DIR sdc 01_fail.sdc]

read_lib $LIB
read_verilog $NETLIST
set_top_module eco_lab04
read_sdc $SDC

puts ""
puts "======================================================================"
puts "ECO_LAB 04 - QUESTION (FAIL): EXPECTED HAND CALCULATION"
puts "======================================================================"
puts "Path          : U_LAUNCH/CLK -> U_LAUNCH/Q -> 6 x XOR2_X1 -> U_CAPTURE/D"
puts "Flip-flops    : launch DFFNEG_X1 (falling edge), capture DFFPOS_X1 (rising edge)"
puts "Library       : CLK->Q = 0.20, setup = 0.20, hold = 0.10 ns  (2-input gates: side pin tied to non-controlling value)"
puts "Data path     : 6 x 0.70 = 4.20 ns"
puts "Arrival time  : CLK->Q + data = 0.20 + 4.20 = 4.40 ns"
puts ""
puts "--- SETUP CHECK (report_timing -late) ---"
puts "Launch edge   : 4.50 ns, capture edge: 9.00 ns -> phase shift 4.50 ns"
puts "Required time : 4.50 - 0.20 = 4.30 ns   (phase shift - setup)"
puts "Setup slack   : Required - Arrival = 4.30 - 4.40 = -0.10 ns  -> VIOLATED"
puts ""
puts "--- HOLD CHECK (report_timing -early) ---"
puts "Launch edge   : 4.50 ns, hold capture edge: 0.00 ns -> phase shift -4.50 ns"
puts "Required time : (-4.50) + 0.10 = -4.40 ns   (phase shift + hold)"
puts "Hold slack    : Arrival - Required = 4.40 - (-4.40) = +8.80 ns  -> MET"
puts "======================================================================"
puts "ACTUAL TEMPUS TIMING REPORTS FOLLOW"
puts "======================================================================"
puts "\n----- SETUP (late) report -----"
report_timing -late -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
puts "\n----- HOLD (early) report -----"
report_timing -early -path_type full_clock -from [get_pins U_LAUNCH/CLK] -to [get_pins U_CAPTURE/D] -max_paths 1
exit
